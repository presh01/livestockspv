-- Livestock Fattening SPV Database Schema
-- PostgreSQL Compatible

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users Table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    national_id VARCHAR(20) UNIQUE NOT NULL,
    phone_number VARCHAR(20),
    employment_status VARCHAR(50),
    location VARCHAR(255),
    email_verified BOOLEAN DEFAULT FALSE,
    email_verification_token VARCHAR(255),
    role VARCHAR(20) DEFAULT 'investor' CHECK (role IN ('investor', 'admin', 'reviewer')),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'suspended')),
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Applications Table
CREATE TABLE applications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    application_number VARCHAR(50) UNIQUE NOT NULL,
    investment_option VARCHAR(20) NOT NULL CHECK (investment_option IN ('outright', 'financing')),
    investment_amount DECIMAL(15,2),
    monthly_repayment DECIMAL(10,2),
    credit_consent BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'under_review', 'approved', 'rejected', 'withdrawn')),
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMP,
    approval_notes TEXT,
    rejection_reason TEXT,
    documents JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Investments Table
CREATE TABLE investments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    application_id UUID REFERENCES applications(id) ON DELETE CASCADE,
    investment_number VARCHAR(50) UNIQUE NOT NULL,
    cattle_count INTEGER DEFAULT 0 CHECK (cattle_count >= 0),
    total_investment DECIMAL(15,2) DEFAULT 0 CHECK (total_investment >= 0),
    current_value DECIMAL(15,2) DEFAULT 0 CHECK (current_value >= 0),
    total_returns DECIMAL(15,2) DEFAULT 0 CHECK (total_returns >= 0),
    last_payout_date DATE,
    next_payout_date DATE,
    expected_roi DECIMAL(5,2) DEFAULT 18.0,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'matured', 'withdrawn', 'suspended')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Transactions Table
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    investment_id UUID REFERENCES investments(id) ON DELETE CASCADE,
    transaction_type VARCHAR(20) NOT NULL CHECK (transaction_type IN ('investment', 'return', 'payout', 'withdrawal', 'fee')),
    amount DECIMAL(15,2) NOT NULL CHECK (amount > 0),
    description TEXT,
    reference_number VARCHAR(100) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'failed', 'cancelled')),
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notifications Table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(20) NOT NULL CHECK (type IN ('email', 'sms', 'in_app')),
    category VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    data JSONB DEFAULT '{}'::jsonb,
    read_at TIMESTAMP,
    sent_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Audit Log Table
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(50) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id UUID,
    old_values JSONB DEFAULT '{}'::jsonb,
    new_values JSONB DEFAULT '{}'::jsonb,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- System Settings Table
CREATE TABLE system_settings (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cattle Registry Table
CREATE TABLE cattle_registry (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tag_number VARCHAR(50) UNIQUE NOT NULL,
    breed VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    weight_kg DECIMAL(6,2),
    health_status VARCHAR(20) DEFAULT 'healthy' CHECK (health_status IN ('healthy', 'sick', 'quarantined', 'deceased')),
    location VARCHAR(255),
    purchase_date DATE,
    purchase_price DECIMAL(10,2),
    current_value DECIMAL(10,2),
    owner_investment_id UUID REFERENCES investments(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Payout Schedule Table
CREATE TABLE payout_schedule (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    investment_id UUID REFERENCES investments(id) ON DELETE CASCADE,
    scheduled_date DATE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    type VARCHAR(20) DEFAULT 'monthly' CHECK (type IN ('monthly', 'quarterly', 'annual', 'maturity')),
    status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'paid', 'cancelled')),
    paid_at TIMESTAMP,
    transaction_id UUID REFERENCES transactions(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for Performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_national_id ON users(national_id);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_role ON users(role);

CREATE INDEX idx_applications_user_id ON applications(user_id);
CREATE INDEX idx_applications_status ON applications(status);
CREATE INDEX idx_applications_created_at ON applications(created_at);

CREATE INDEX idx_investments_user_id ON investments(user_id);
CREATE INDEX idx_investments_status ON investments(status);
CREATE INDEX idx_investments_created_at ON investments(created_at);

CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_investment_id ON transactions(investment_id);
CREATE INDEX idx_transactions_created_at ON transactions(created_at);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_read_at ON notifications(read_at);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);

CREATE INDEX idx_cattle_owner_investment_id ON cattle_registry(owner_investment_id);
CREATE INDEX idx_cattle_health_status ON cattle_registry(health_status);

CREATE INDEX idx_payout_schedule_investment_id ON payout_schedule(investment_id);
CREATE INDEX idx_payout_schedule_scheduled_date ON payout_schedule(scheduled_date);

-- Triggers for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_applications_updated_at BEFORE UPDATE ON applications 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_investments_updated_at BEFORE UPDATE ON investments 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON transactions 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert default system settings
INSERT INTO system_settings (key, value, description) VALUES
    ('min_outright_investment', '500000', 'Minimum investment for outright purchase (Naira)'),
    ('min_monthly_repayment', '50000', 'Minimum monthly repayment for financing option (Naira)'),
    ('default_roi_percentage', '18.0', 'Default annual ROI percentage'),
    ('application_expiry_days', '30', 'Number of days before application expires'),
    ('max_cattle_per_investment', '10', 'Maximum number of cattle per investment'),
    ('payout_schedule_days', '30', 'Days between payout schedules'),
    ('maintenance_fee_percentage', '2.5', 'Annual maintenance fee percentage'),
    ('insurance_fee_percentage', '1.5', 'Annual insurance fee percentage');

-- Create views for common queries
CREATE VIEW active_investments AS
SELECT 
    i.*,
    u.full_name,
    u.email,
    u.phone_number,
    a.investment_option,
    a.application_number
FROM investments i
JOIN users u ON i.user_id = u.id
JOIN applications a ON i.application_id = a.id
WHERE i.status = 'active';

CREATE VIEW pending_applications AS
SELECT 
    a.*,
    u.full_name,
    u.email,
    u.phone_number,
    u.employment_status,
    u.location
FROM applications a
JOIN users u ON a.user_id = u.id
WHERE a.status = 'pending';

CREATE VIEW user_dashboard AS
SELECT 
    u.id as user_id,
    u.full_name,
    u.email,
    COUNT(i.id) as total_investments,
    COALESCE(SUM(i.total_investment), 0) as total_invested,
    COALESCE(SUM(i.current_value), 0) as current_value,
    COALESCE(SUM(i.total_returns), 0) as total_returns,
    MAX(i.created_at) as last_investment_date
FROM users u
LEFT JOIN investments i ON u.id = i.user_id AND i.status = 'active'
WHERE u.status = 'approved'
GROUP BY u.id, u.full_name, u.email;