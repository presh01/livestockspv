const { pool } = require('./database/connection');
const { generateReport } = require('./utils/reports');
const { sendEmail } = require('./utils/email');
const { createNotification } = require('./utils/notifications');

class AdminService {
    async getDashboardStats() {
        const client = await pool.connect();
        
        try {
            // Get comprehensive statistics
            const statsQuery = `
                WITH monthly_stats AS (
                    SELECT 
                        DATE_TRUNC('month', created_at) as month,
                        COUNT(*) as applications,
                        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                        SUM(investment_amount) as total_investment
                    FROM applications 
                    WHERE created_at >= CURRENT_DATE - INTERVAL '12 months'
                    GROUP BY DATE_TRUNC('month', created_at)
                )
                SELECT 
                    -- User statistics
                    (SELECT COUNT(*) FROM users WHERE status = 'approved') as total_users,
                    (SELECT COUNT(*) FROM users WHERE status = 'pending') as pending_users,
                    (SELECT COUNT(*) FROM users WHERE created_at >= CURRENT_DATE - INTERVAL '30 days') as new_users_this_month,
                    
                    -- Application statistics
                    (SELECT COUNT(*) FROM applications) as total_applications,
                    (SELECT COUNT(*) FROM applications WHERE status = 'pending') as pending_applications,
                    (SELECT COUNT(*) FROM applications WHERE status = 'approved') as approved_applications,
                    (SELECT COUNT(*) FROM applications WHERE status = 'rejected') as rejected_applications,
                    
                    -- Investment statistics
                    (SELECT COUNT(*) FROM investments WHERE status = 'active') as active_investments,
                    (SELECT COALESCE(SUM(total_investment), 0) FROM investments WHERE status = 'active') as total_invested,
                    (SELECT COALESCE(SUM(current_value), 0) FROM investments WHERE status = 'active') as current_value,
                    (SELECT COALESCE(SUM(total_returns), 0) FROM investments) as total_returns_paid,
                    
                    -- Cattle statistics
                    (SELECT COUNT(*) FROM cattle_registry WHERE health_status = 'healthy') as healthy_cattle,
                    (SELECT COUNT(*) FROM cattle_registry WHERE health_status != 'healthy') as sick_cattle,
                    
                    -- Monthly trend
                    (SELECT json_agg(monthly_stats) FROM monthly_stats) as monthly_trend
            `;
            
            const result = await client.query(statsQuery);
            
            return {
                success: true,
                stats: result.rows[0]
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async getUsers(filters = {}) {
        const client = await pool.connect();
        
        try {
            let query = `
                SELECT u.*,
                       COUNT(i.id) as total_investments,
                       COALESCE(SUM(i.total_investment), 0) as total_invested,
                       MAX(i.created_at) as last_investment_date
                FROM users u
                LEFT JOIN investments i ON u.id = i.user_id AND i.status = 'active'
            `;
            
            const params = [];
            const conditions = [];
            
            // Apply filters
            if (filters.role) {
                params.push(filters.role);
                conditions.push(`u.role = $${params.length}`);
            }
            
            if (filters.status) {
                params.push(filters.status);
                conditions.push(`u.status = $${params.length}`);
            }
            
            if (filters.search) {
                params.push(`%${filters.search}%`);
                conditions.push(`(u.full_name ILIKE $${params.length} OR u.email ILIKE $${params.length})`);
            }
            
            if (conditions.length > 0) {
                query += ' WHERE ' + conditions.join(' AND ');
            }
            
            query += ' GROUP BY u.id ORDER BY u.created_at DESC';
            
            if (filters.limit) {
                params.push(filters.limit);
                query += ` LIMIT $${params.length}`;
            }
            
            if (filters.offset) {
                params.push(filters.offset);
                query += ` OFFSET $${params.length}`;
            }
            
            const result = await client.query(query, params);
            
            return {
                success: true,
                users: result.rows,
                count: result.rows.length
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async getUser(userId) {
        const client = await pool.connect();
        
        try {
            const userQuery = `
                SELECT u.*,
                       COUNT(i.id) as total_investments,
                       COALESCE(SUM(i.total_investment), 0) as total_invested,
                       COALESCE(SUM(i.current_value), 0) as current_value,
                       COALESCE(SUM(i.total_returns), 0) as total_returns,
                       MAX(i.created_at) as last_investment_date
                FROM users u
                LEFT JOIN investments i ON u.id = i.user_id
                WHERE u.id = $1
                GROUP BY u.id
            `;
            
            const userResult = await client.query(userQuery, [userId]);
            
            if (userResult.rows.length === 0) {
                throw new Error('User not found');
            }
            
            const user = userResult.rows[0];
            
            // Get user's investments
            const investmentsQuery = `
                SELECT i.*, a.application_number
                FROM investments i
                JOIN applications a ON i.application_id = a.id
                WHERE i.user_id = $1
                ORDER BY i.created_at DESC
            `;
            
            const investmentsResult = await client.query(investmentsQuery, [userId]);
            
            // Get user's applications
            const applicationsQuery = `
                SELECT a.*, 
                       rv.full_name as reviewed_by_name
                FROM applications a
                LEFT JOIN users rv ON a.reviewed_by = rv.id
                WHERE a.user_id = $1
                ORDER BY a.created_at DESC
            `;
            
            const applicationsResult = await client.query(applicationsQuery, [userId]);
            
            // Get recent transactions
            const transactionsQuery = `
                SELECT * FROM transactions 
                WHERE user_id = $1 
                ORDER BY created_at DESC 
                LIMIT 10
            `;
            
            const transactionsResult = await client.query(transactionsQuery, [userId]);
            
            return {
                success: true,
                user: {
                    ...user,
                    investments: investmentsResult.rows,
                    applications: applicationsResult.rows,
                    recent_transactions: transactionsResult.rows
                }
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async updateUserStatus(adminId, userId, status, reason = '') {
        const client = await pool.connect();
        
        try {
            await client.query('BEGIN');
            
            // Get current user status
            const currentUser = await client.query(
                'SELECT status, email, full_name FROM users WHERE id = $1',
                [userId]
            );
            
            if (currentUser.rows.length === 0) {
                throw new Error('User not found');
            }
            
            const user = currentUser.rows[0];
            const oldStatus = user.status;
            
            // Update user status
            const updateResult = await client.query(
                'UPDATE users SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *',
                [status, userId]
            );
            
            const updatedUser = updateResult.rows[0];
            
            // Send notification based on status
            if (status === 'suspended') {
                await sendEmail({
                    to: user.email,
                    subject: 'Account Suspended - LivestockSPV',
                    template: 'account-suspended',
                    data: {
                        full_name: user.full_name,
                        reason: reason
                    }
                });
            } else if (status === 'approved' && oldStatus === 'pending') {
                await sendEmail({
                    to: user.email,
                    subject: 'Account Approved - LivestockSPV',
                    template: 'account-approved',
                    data: {
                        full_name: user.full_name
                    }
                });
            }
            
            // Create notification
            await createNotification({
                userId: userId,
                type: 'in_app',
                category: 'account',
                title: `Account ${status}`,
                message: `Your account status has been changed to ${status}.`,
                data: { 
                    status: status,
                    reason: reason
                }
            });
            
            await client.query('COMMIT');
            
            // Log audit event
            await this.logAuditEvent(adminId, 'user_status_updated', 'users', userId, 
                { status: oldStatus }, { status: status, reason: reason });
            
            return {
                success: true,
                message: `User status updated to ${status}`,
                user: updatedUser
            };
            
        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }
    
    async getApplications(filters = {}) {
        const client = await pool.connect();
        
        try {
            let query = `
                SELECT a.*, u.full_name, u.email, u.phone_number, 
                       u.employment_status, u.location,
                       rv.full_name as reviewed_by_name
                FROM applications a
                JOIN users u ON a.user_id = u.id
                LEFT JOIN users rv ON a.reviewed_by = rv.id
            `;
            
            const params = [];
            const conditions = [];
            
            // Apply filters
            if (filters.status) {
                params.push(filters.status);
                conditions.push(`a.status = $${params.length}`);
            }
            
            if (filters.investmentOption) {
                params.push(filters.investmentOption);
                conditions.push(`a.investment_option = $${params.length}`);
            }
            
            if (filters.search) {
                params.push(`%${filters.search}%`);
                conditions.push(`(u.full_name ILIKE $${params.length} OR u.email ILIKE $${params.length} OR a.application_number ILIKE $${params.length})`);
            }
            
            if (filters.startDate) {
                params.push(filters.startDate);
                conditions.push(`a.created_at >= $${params.length}`);
            }
            
            if (filters.endDate) {
                params.push(filters.endDate);
                conditions.push(`a.created_at <= $${params.length}`);
            }
            
            if (conditions.length > 0) {
                query += ' WHERE ' + conditions.join(' AND ');
            }
            
            query += ' ORDER BY a.created_at DESC';
            
            if (filters.limit) {
                params.push(filters.limit);
                query += ` LIMIT $${params.length}`;
            }
            
            if (filters.offset) {
                params.push(filters.offset);
                query += ` OFFSET $${params.length}`;
            }
            
            const result = await client.query(query, params);
            
            return {
                success: true,
                applications: result.rows,
                count: result.rows.length
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async getInvestments(filters = {}) {
        const client = await pool.connect();
        
        try {
            let query = `
                SELECT i.*, u.full_name, u.email, a.application_number
                FROM investments i
                JOIN users u ON i.user_id = u.id
                JOIN applications a ON i.application_id = a.id
            `;
            
            const params = [];
            const conditions = [];
            
            // Apply filters
            if (filters.status) {
                params.push(filters.status);
                conditions.push(`i.status = $${params.length}`);
            }
            
            if (filters.userId) {
                params.push(filters.userId);
                conditions.push(`i.user_id = $${params.length}`);
            }
            
            if (filters.search) {
                params.push(`%${filters.search}%`);
                conditions.push(`(u.full_name ILIKE $${params.length} OR u.email ILIKE $${params.length})`);
            }
            
            if (conditions.length > 0) {
                query += ' WHERE ' + conditions.join(' AND ');
            }
            
            query += ' ORDER BY i.created_at DESC';
            
            if (filters.limit) {
                params.push(filters.limit);
                query += ` LIMIT $${params.length}`;
            }
            
            if (filters.offset) {
                params.push(filters.offset);
                query += ` OFFSET $${params.length}`;
            }
            
            const result = await client.query(query, params);
            
            return {
                success: true,
                investments: result.rows,
                count: result.rows.length
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async generateReport(type, filters = {}) {
        try {
            let reportData;
            
            switch (type) {
                case 'users':
                    reportData = await this.generateUsersReport(filters);
                    break;
                case 'applications':
                    reportData = await this.generateApplicationsReport(filters);
                    break;
                case 'investments':
                    reportData = await this.generateInvestmentsReport(filters);
                    break;
                case 'financial':
                    reportData = await this.generateFinancialReport(filters);
                    break;
                default:
                    throw new Error('Invalid report type');
            }
            
            return {
                success: true,
                report: reportData
            };
            
        } catch (error) {
            throw error;
        }
    }
    
    async generateUsersReport(filters) {
        const client = await pool.connect();
        
        try {
            let query = `
                SELECT 
                    u.id, u.full_name, u.email, u.phone_number,
                    u.employment_status, u.location, u.role, u.status,
                    u.created_at, u.last_login,
                    COUNT(i.id) as total_investments,
                    COALESCE(SUM(i.total_investment), 0) as total_invested
                FROM users u
                LEFT JOIN investments i ON u.id = i.user_id AND i.status = 'active'
            `;
            
            const params = [];
            const conditions = [];
            
            if (filters.role) {
                params.push(filters.role);
                conditions.push(`u.role = $${params.length}`);
            }
            
            if (filters.status) {
                params.push(filters.status);
                conditions.push(`u.status = $${params.length}`);
            }
            
            if (filters.startDate) {
                params.push(filters.startDate);
                conditions.push(`u.created_at >= $${params.length}`);
            }
            
            if (filters.endDate) {
                params.push(filters.endDate);
                conditions.push(`u.created_at <= $${params.length}`);
            }
            
            if (conditions.length > 0) {
                query += ' WHERE ' + conditions.join(' AND ');
            }
            
            query += ' GROUP BY u.id ORDER BY u.created_at DESC';
            
            const result = await client.query(query, params);
            
            return {
                type: 'users',
                generated_at: new Date().toISOString(),
                filters: filters,
                data: result.rows,
                summary: {
                    total_users: result.rows.length,
                    total_invested: result.rows.reduce((sum, row) => sum + parseFloat(row.total_invested), 0)
                }
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async generateApplicationsReport(filters) {
        const client = await pool.connect();
        
        try {
            let query = `
                SELECT 
                    a.*, u.full_name, u.email, u.employment_status, u.location
                FROM applications a
                JOIN users u ON a.user_id = u.id
            `;
            
            const params = [];
            const conditions = [];
            
            if (filters.status) {
                params.push(filters.status);
                conditions.push(`a.status = $${params.length}`);
            }
            
            if (filters.investmentOption) {
                params.push(filters.investmentOption);
                conditions.push(`a.investment_option = $${params.length}`);
            }
            
            if (filters.startDate) {
                params.push(filters.startDate);
                conditions.push(`a.created_at >= $${params.length}`);
            }
            
            if (filters.endDate) {
                params.push(filters.endDate);
                conditions.push(`a.created_at <= $${params.length}`);
            }
            
            if (conditions.length > 0) {
                query += ' WHERE ' + conditions.join(' AND ');
            }
            
            query += ' ORDER BY a.created_at DESC';
            
            const result = await client.query(query, params);
            
            return {
                type: 'applications',
                generated_at: new Date().toISOString(),
                filters: filters,
                data: result.rows,
                summary: {
                    total_applications: result.rows.length,
                    total_investment: result.rows.reduce((sum, row) => sum + parseFloat(row.investment_amount || 0), 0),
                    status_breakdown: result.rows.reduce((acc, row) => {
                        acc[row.status] = (acc[row.status] || 0) + 1;
                        return acc;
                    }, {})
                }
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async generateInvestmentsReport(filters) {
        const client = await pool.connect();
        
        try {
            let query = `
                SELECT 
                    i.*, u.full_name, u.email, a.application_number
                FROM investments i
                JOIN users u ON i.user_id = u.id
                JOIN applications a ON i.application_id = a.id
            `;
            
            const params = [];
            const conditions = [];
            
            if (filters.status) {
                params.push(filters.status);
                conditions.push(`i.status = $${params.length}`);
            }
            
            if (filters.startDate) {
                params.push(filters.startDate);
                conditions.push(`i.created_at >= $${params.length}`);
            }
            
            if (filters.endDate) {
                params.push(filters.endDate);
                conditions.push(`i.created_at <= $${params.length}`);
            }
            
            if (conditions.length > 0) {
                query += ' WHERE ' + conditions.join(' AND ');
            }
            
            query += ' ORDER BY i.created_at DESC';
            
            const result = await client.query(query, params);
            
            return {
                type: 'investments',
                generated_at: new Date().toISOString(),
                filters: filters,
                data: result.rows,
                summary: {
                    total_investments: result.rows.length,
                    total_invested: result.rows.reduce((sum, row) => sum + parseFloat(row.total_investment), 0),
                    total_current_value: result.rows.reduce((sum, row) => sum + parseFloat(row.current_value), 0),
                    total_returns: result.rows.reduce((sum, row) => sum + parseFloat(row.total_returns), 0),
                    status_breakdown: result.rows.reduce((acc, row) => {
                        acc[row.status] = (acc[row.status] || 0) + 1;
                        return acc;
                    }, {})
                }
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async generateFinancialReport(filters) {
        const client = await pool.connect();
        
        try {
            // Get financial summary
            const financialQuery = `
                SELECT 
                    -- Investment summary
                    (SELECT COALESCE(SUM(total_investment), 0) FROM investments WHERE status = 'active') as total_invested,
                    (SELECT COALESCE(SUM(current_value), 0) FROM investments WHERE status = 'active') as current_portfolio_value,
                    (SELECT COALESCE(SUM(total_returns), 0) FROM investments) as total_returns_paid,
                    
                    -- Monthly returns
                    (SELECT 
                        json_agg(json_build_object(
                            'month', DATE_TRUNC('month', created_at),
                            'returns_paid', SUM(amount)
                        ))
                     FROM transactions 
                     WHERE transaction_type = 'return' 
                     AND created_at >= CURRENT_DATE - INTERVAL '12 months'
                     GROUP BY DATE_TRUNC('month', created_at)
                    ) as monthly_returns,
                    
                    -- Outstanding payouts
                    (SELECT COALESCE(SUM(amount), 0) FROM payout_schedule WHERE status = 'scheduled') as outstanding_payouts,
                    
                    -- Fees collected
                    (SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE transaction_type = 'fee') as total_fees
            `;
            
            const result = await client.query(financialQuery);
            
            return {
                type: 'financial',
                generated_at: new Date().toISOString(),
                filters: filters,
                data: result.rows[0],
                summary: {
                    total_invested: result.rows[0].total_invested,
                    current_portfolio_value: result.rows[0].current_portfolio_value,
                    total_returns_paid: result.rows[0].total_returns_paid,
                    net_portfolio_value: result.rows[0].current_portfolio_value - result.rows[0].total_invested,
                    outstanding_payouts: result.rows[0].outstanding_payouts,
                    total_fees: result.rows[0].total_fees
                }
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async logAuditEvent(userId, action, resourceType, resourceId, oldValues = {}, newValues = {}) {
        try {
            await pool.query(
                `INSERT INTO audit_logs (user_id, action, resource_type, resource_id, old_values, new_values) 
                 VALUES ($1, $2, $3, $4, $5, $6)`,
                [userId, action, resourceType, resourceId, JSON.stringify(oldValues), JSON.stringify(newValues)]
            );
        } catch (error) {
            console.error('Audit logging error:', error);
        }
    }
}

module.exports = new AdminService();