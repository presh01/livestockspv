const { pool } = require('../database/connection');
const { generateApplicationNumber } = require('../utils/helpers');
const { sendEmail } = require('../utils/email');
const { createNotification } = require('../utils/notifications');

class ApplicationService {
    async submitApplication(userId, applicationData) {
        const client = await pool.connect();
        
        try {
            await client.query('BEGIN');
            
            // Check if user has existing pending application
            const existingApp = await client.query(
                'SELECT id FROM applications WHERE user_id = $1 AND status IN ($2, $3)',
                [userId, 'pending', 'under_review']
            );
            
            if (existingApp.rows.length > 0) {
                throw new Error('You already have a pending application');
            }
            
            // Generate application number
            const applicationNumber = generateApplicationNumber();
            
            // Insert application
            const applicationResult = await client.query(
                `INSERT INTO applications (user_id, application_number, investment_option, 
                 investment_amount, monthly_repayment, credit_consent, documents) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
                [
                    userId,
                    applicationNumber,
                    applicationData.investment_option,
                    applicationData.investment_amount,
                    applicationData.monthly_repayment,
                    applicationData.credit_consent,
                    JSON.stringify(applicationData.documents || [])
                ]
            );
            
            const application = applicationResult.rows[0];
            
            // Get user details
            const userResult = await client.query(
                'SELECT full_name, email FROM users WHERE id = $1',
                [userId]
            );
            const user = userResult.rows[0];
            
            // Send confirmation email
            await sendEmail({
                to: user.email,
                subject: 'Application Received - LivestockSPV',
                template: 'application-received',
                data: {
                    full_name: user.full_name,
                    application_number: applicationNumber,
                    investment_option: applicationData.investment_option
                }
            });
            
            // Create in-app notification
            await createNotification({
                userId: userId,
                type: 'in_app',
                category: 'application',
                title: 'Application Submitted',
                message: `Your application ${applicationNumber} has been submitted successfully.`,
                data: { application_id: application.id }
            });
            
            // Notify admins
            await this.notifyAdmins('New Application', 
                `New application ${applicationNumber} from ${user.full_name}`);
            
            await client.query('COMMIT');
            
            // Log audit event
            await this.logAuditEvent(userId, 'application_submitted', 'applications', application.id, {}, application);
            
            return {
                success: true,
                message: 'Application submitted successfully',
                application: {
                    id: application.id,
                    application_number: application.application_number,
                    status: application.status,
                    created_at: application.created_at
                }
            };
            
        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }
    
    async getApplications(userId, role = 'investor', filters = {}) {
        const client = await pool.connect();
        
        try {
            let query = `
                SELECT a.*, u.full_name, u.email, u.phone_number, 
                       u.employment_status, u.location
                FROM applications a
                JOIN users u ON a.user_id = u.id
            `;
            
            const params = [];
            const conditions = [];
            
            // Role-based filtering
            if (role === 'investor') {
                conditions.push('a.user_id = $1');
                params.push(userId);
            }
            
            // Additional filters
            if (filters.status) {
                params.push(filters.status);
                conditions.push(`a.status = $${params.length}`);
            }
            
            if (filters.startDate) {
                params.push(filters.startDate);
                conditions.push(`a.created_at >= $${params.length}`);
            }
            
            if (filters.endDate) {
                params.push(filters.endDate);
                conditions.push(`a.created_at <= $${params.length}`);
            }
            
            if (conditions.length > 0) {
                query += ' WHERE ' + conditions.join(' AND ');
            }
            
            query += ' ORDER BY a.created_at DESC';
            
            if (filters.limit) {
                params.push(filters.limit);
                query += ` LIMIT $${params.length}`;
            }
            
            if (filters.offset) {
                params.push(filters.offset);
                query += ` OFFSET $${params.length}`;
            }
            
            const result = await client.query(query, params);
            
            return {
                success: true,
                applications: result.rows,
                count: result.rows.length
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async getApplication(userId, applicationId, role = 'investor') {
        const client = await pool.connect();
        
        try {
            let query = `
                SELECT a.*, u.full_name, u.email, u.phone_number, 
                       u.employment_status, u.location,
                       rv.full_name as reviewed_by_name
                FROM applications a
                JOIN users u ON a.user_id = u.id
                LEFT JOIN users rv ON a.reviewed_by = rv.id
            `;
            
            const params = [applicationId];
            const conditions = ['a.id = $1'];
            
            // Role-based filtering
            if (role === 'investor') {
                params.push(userId);
                conditions.push(`a.user_id = $${params.length}`);
            }
            
            query += ' WHERE ' + conditions.join(' AND ');
            
            const result = await client.query(query, params);
            
            if (result.rows.length === 0) {
                throw new Error('Application not found');
            }
            
            return {
                success: true,
                application: result.rows[0]
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async updateApplicationStatus(adminId, applicationId, status, notes = '') {
        const client = await pool.connect();
        
        try {
            await client.query('BEGIN');
            
            // Get current application status
            const currentApp = await client.query(
                'SELECT * FROM applications WHERE id = $1',
                [applicationId]
            );
            
            if (currentApp.rows.length === 0) {
                throw new Error('Application not found');
            }
            
            const application = currentApp.rows[0];
            const oldStatus = application.status;
            
            // Update application status
            const updateQuery = `
                UPDATE applications 
                SET status = $1, reviewed_by = $2, reviewed_at = CURRENT_TIMESTAMP, 
                    approval_notes = $3, updated_at = CURRENT_TIMESTAMP
                WHERE id = $4 RETURNING *
            `;
            
            const updatedApp = await client.query(updateQuery, [
                status, adminId, notes, applicationId
            ]);
            
            const updatedApplication = updatedApp.rows[0];
            
            // Get user details
            const userResult = await client.query(
                'SELECT full_name, email FROM users WHERE id = $1',
                [application.user_id]
            );
            const user = userResult.rows[0];
            
            // Handle approval - create investment
            if (status === 'approved') {
                await this.createInvestment(application.user_id, applicationId, application);
                
                // Send approval email
                await sendEmail({
                    to: user.email,
                    subject: 'Application Approved - LivestockSPV',
                    template: 'application-approved',
                    data: {
                        full_name: user.full_name,
                        application_number: application.application_number,
                        approval_notes: notes
                    }
                });
            }
            
            // Handle rejection
            if (status === 'rejected') {
                await sendEmail({
                    to: user.email,
                    subject: 'Application Update - LivestockSPV',
                    template: 'application-rejected',
                    data: {
                        full_name: user.full_name,
                        application_number: application.application_number,
                        rejection_reason: notes
                    }
                });
            }
            
            // Create notification
            await createNotification({
                userId: application.user_id,
                type: 'in_app',
                category: 'application',
                title: `Application ${status}`,
                message: `Your application ${application.application_number} has been ${status}.`,
                data: { 
                    application_id: applicationId,
                    status: status,
                    notes: notes
                }
            });
            
            await client.query('COMMIT');
            
            // Log audit event
            await this.logAuditEvent(adminId, 'application_status_updated', 'applications', applicationId, 
                { status: oldStatus }, { status: status, notes: notes });
            
            return {
                success: true,
                message: `Application status updated to ${status}`,
                application: updatedApplication
            };
            
        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }
    
    async createInvestment(userId, applicationId, application) {
        const client = await pool.connect();
        
        try {
            // Generate investment number
            const investmentNumber = `INV-${Date.now()}-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
            
            // Calculate initial values
            const totalInvestment = application.investment_amount || 0;
            const cattleCount = Math.floor(totalInvestment / 500000) || 1; // Default 1 cattle
            
            // Create investment
            const investmentResult = await client.query(
                `INSERT INTO investments (user_id, application_id, investment_number, cattle_count, 
                 total_investment, current_value, expected_roi) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
                [
                    userId,
                    applicationId,
                    investmentNumber,
                    cattleCount,
                    totalInvestment,
                    totalInvestment, // Initial current value
                    18.0 // Default ROI
                ]
            );
            
            const investment = investmentResult.rows[0];
            
            // Create cattle registry entries
            for (let i = 0; i < cattleCount; i++) {
                const tagNumber = `CATTLE-${investmentNumber}-${i + 1}`;
                await client.query(
                    `INSERT INTO cattle_registry (tag_number, breed, owner_investment_id, purchase_price) 
                     VALUES ($1, $2, $3, $4)`,
                    [tagNumber, 'Mixed Breed', investment.id, 500000]
                );
            }
            
            // Create initial transaction
            const transactionResult = await client.query(
                `INSERT INTO transactions (user_id, investment_id, transaction_type, amount, 
                 description, reference_number) 
                 VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
                [
                    userId,
                    investment.id,
                    'investment',
                    totalInvestment,
                    'Initial investment',
                    `TXN-${Date.now()}`
                ]
            );
            
            // Schedule first payout
            const nextPayoutDate = new Date();
            nextPayoutDate.setMonth(nextPayoutDate.getMonth() + 1);
            
            await client.query(
                `INSERT INTO payout_schedule (investment_id, scheduled_date, amount, type) 
                 VALUES ($1, $2, $3, $4)`,
                [
                    investment.id,
                    nextPayoutDate,
                    totalInvestment * 0.015, // 1.5% monthly
                    'monthly'
                ]
            );
            
            return investment;
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async getApplicationStats() {
        const client = await pool.connect();
        
        try {
            const statsQuery = `
                SELECT 
                    COUNT(*) as total_applications,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_applications,
                    COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_applications,
                    COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected_applications,
                    AVG(EXTRACT(EPOCH FROM (reviewed_at - created_at))/3600) as avg_review_hours
                FROM applications
                WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
            `;
            
            const result = await client.query(statsQuery);
            
            return {
                success: true,
                stats: result.rows[0]
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async notifyAdmins(title, message) {
        try {
            // Get all admin users
            const adminResult = await pool.query(
                'SELECT id FROM users WHERE role = $1',
                ['admin']
            );
            
            for (const admin of adminResult.rows) {
                await createNotification({
                    userId: admin.id,
                    type: 'in_app',
                    category: 'admin',
                    title: title,
                    message: message
                });
            }
        } catch (error) {
            console.error('Error notifying admins:', error);
        }
    }
    
    async logAuditEvent(userId, action, resourceType, resourceId, oldValues = {}, newValues = {}) {
        try {
            await pool.query(
                `INSERT INTO audit_logs (user_id, action, resource_type, resource_id, old_values, new_values) 
                 VALUES ($1, $2, $3, $4, $5, $6)`,
                [userId, action, resourceType, resourceId, JSON.stringify(oldValues), JSON.stringify(newValues)]
            );
        } catch (error) {
            console.error('Audit logging error:', error);
        }
    }
}

module.exports = new ApplicationService();