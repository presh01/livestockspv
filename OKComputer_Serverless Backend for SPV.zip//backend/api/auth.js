const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { pool } = require('../database/connection');
const { sendEmail } = require('../utils/email');
const { generateApplicationNumber } = require('../utils/helpers');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

class AuthService {
    async register(userData) {
        const client = await pool.connect();
        
        try {
            await client.query('BEGIN');
            
            // Check if user already exists
            const existingUser = await client.query(
                'SELECT id FROM users WHERE email = $1 OR national_id = $2',
                [userData.email, userData.national_id]
            );
            
            if (existingUser.rows.length > 0) {
                throw new Error('User with this email or National ID already exists');
            }
            
            // Hash password
            const saltRounds = 12;
            const passwordHash = await bcrypt.hash(userData.password, saltRounds);
            
            // Generate email verification token
            const verificationToken = uuidv4();
            
            // Create user
            const userResult = await client.query(
                `INSERT INTO users (email, password_hash, full_name, national_id, phone_number, 
                 employment_status, location, email_verification_token) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
                [
                    userData.email,
                    passwordHash,
                    userData.full_name,
                    userData.national_id,
                    userData.phone_number,
                    userData.employment_status,
                    userData.location,
                    verificationToken
                ]
            );
            
            const user = userResult.rows[0];
            
            // Create application
            const applicationNumber = generateApplicationNumber();
            await client.query(
                `INSERT INTO applications (user_id, application_number, investment_option, 
                 investment_amount, monthly_repayment, credit_consent) 
                 VALUES ($1, $2, $3, $4, $5, $6)`,
                [
                    user.id,
                    applicationNumber,
                    userData.investment_option,
                    userData.investment_amount,
                    userData.monthly_repayment,
                    userData.credit_consent
                ]
            );
            
            // Send verification email
            await sendEmail({
                to: userData.email,
                subject: 'Welcome to LivestockSPV - Verify Your Email',
                template: 'email-verification',
                data: {
                    full_name: userData.full_name,
                    verification_token: verificationToken,
                    application_number: applicationNumber
                }
            });
            
            await client.query('COMMIT');
            
            // Log audit event
            await this.logAuditEvent(user.id, 'user_registered', 'users', user.id, {}, user);
            
            return {
                success: true,
                message: 'Registration successful. Please check your email for verification.',
                user: {
                    id: user.id,
                    email: user.email,
                    full_name: user.full_name,
                    application_number: applicationNumber
                }
            };
            
        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }
    
    async login(email, password) {
        const client = await pool.connect();
        
        try {
            // Get user with password hash
            const userResult = await client.query(
                'SELECT * FROM users WHERE email = $1',
                [email]
            );
            
            if (userResult.rows.length === 0) {
                throw new Error('Invalid email or password');
            }
            
            const user = userResult.rows[0];
            
            // Check if user is suspended
            if (user.status === 'suspended') {
                throw new Error('Account has been suspended. Please contact support.');
            }
            
            // Verify password
            const isValidPassword = await bcrypt.compare(password, user.password_hash);
            if (!isValidPassword) {
                throw new Error('Invalid email or password');
            }
            
            // Check if email is verified
            if (!user.email_verified) {
                throw new Error('Please verify your email before logging in');
            }
            
            // Generate JWT token
            const token = jwt.sign(
                { 
                    userId: user.id, 
                    email: user.email, 
                    role: user.role 
                },
                JWT_SECRET,
                { expiresIn: JWT_EXPIRES_IN }
            );
            
            // Update last login
            await client.query(
                'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1',
                [user.id]
            );
            
            // Log audit event
            await this.logAuditEvent(user.id, 'user_login', 'users', user.id, {}, user);
            
            return {
                success: true,
                token,
                user: {
                    id: user.id,
                    email: user.email,
                    full_name: user.full_name,
                    role: user.role,
                    status: user.status
                }
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async verifyEmail(token) {
        const client = await pool.connect();
        
        try {
            // Find user with verification token
            const userResult = await client.query(
                'SELECT * FROM users WHERE email_verification_token = $1',
                [token]
            );
            
            if (userResult.rows.length === 0) {
                throw new Error('Invalid verification token');
            }
            
            const user = userResult.rows[0];
            
            // Update user as verified
            await client.query(
                'UPDATE users SET email_verified = TRUE, email_verification_token = NULL, status = $1 WHERE id = $2',
                ['approved', user.id]
            );
            
            // Log audit event
            await this.logAuditEvent(user.id, 'email_verified', 'users', user.id, { email_verified: false }, { email_verified: true });
            
            return {
                success: true,
                message: 'Email verified successfully. You can now log in.'
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async forgotPassword(email) {
        const client = await pool.connect();
        
        try {
            // Find user
            const userResult = await client.query(
                'SELECT * FROM users WHERE email = $1 AND email_verified = TRUE',
                [email]
            );
            
            if (userResult.rows.length === 0) {
                return { success: true, message: 'If the email exists, a reset link has been sent.' };
            }
            
            const user = userResult.rows[0];
            
            // Generate reset token (valid for 1 hour)
            const resetToken = jwt.sign(
                { userId: user.id },
                JWT_SECRET,
                { expiresIn: '1h' }
            );
            
            // Send reset email
            await sendEmail({
                to: email,
                subject: 'Password Reset - LivestockSPV',
                template: 'password-reset',
                data: {
                    full_name: user.full_name,
                    reset_token: resetToken
                }
            });
            
            return {
                success: true,
                message: 'Password reset email sent successfully'
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async resetPassword(token, newPassword) {
        const client = await pool.connect();
        
        try {
            // Verify reset token
            const decoded = jwt.verify(token, JWT_SECRET);
            
            // Hash new password
            const saltRounds = 12;
            const passwordHash = await bcrypt.hash(newPassword, saltRounds);
            
            // Update password
            await client.query(
                'UPDATE users SET password_hash = $1 WHERE id = $2',
                [passwordHash, decoded.userId]
            );
            
            // Log audit event
            await this.logAuditEvent(decoded.userId, 'password_reset', 'users', decoded.userId, {}, { password_changed: true });
            
            return {
                success: true,
                message: 'Password reset successfully'
            };
            
        } catch (error) {
            if (error.name === 'TokenExpiredError') {
                throw new Error('Reset token has expired');
            }
            throw error;
        } finally {
            client.release();
        }
    }
    
    async changePassword(userId, oldPassword, newPassword) {
        const client = await pool.connect();
        
        try {
            // Get current password hash
            const userResult = await client.query(
                'SELECT password_hash FROM users WHERE id = $1',
                [userId]
            );
            
            if (userResult.rows.length === 0) {
                throw new Error('User not found');
            }
            
            // Verify old password
            const isValidPassword = await bcrypt.compare(oldPassword, userResult.rows[0].password_hash);
            if (!isValidPassword) {
                throw new Error('Current password is incorrect');
            }
            
            // Hash new password
            const saltRounds = 12;
            const passwordHash = await bcrypt.hash(newPassword, saltRounds);
            
            // Update password
            await client.query(
                'UPDATE users SET password_hash = $1 WHERE id = $2',
                [passwordHash, userId]
            );
            
            // Log audit event
            await this.logAuditEvent(userId, 'password_changed', 'users', userId, {}, { password_changed: true });
            
            return {
                success: true,
                message: 'Password changed successfully'
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async getProfile(userId) {
        const client = await pool.connect();
        
        try {
            const userResult = await client.query(
                'SELECT id, email, full_name, national_id, phone_number, employment_status, location, role, status, created_at FROM users WHERE id = $1',
                [userId]
            );
            
            if (userResult.rows.length === 0) {
                throw new Error('User not found');
            }
            
            return {
                success: true,
                user: userResult.rows[0]
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async updateProfile(userId, profileData) {
        const client = await pool.connect();
        
        try {
            const allowedFields = ['full_name', 'phone_number', 'location'];
            const updates = [];
            const values = [];
            let paramCount = 1;
            
            // Build dynamic update query
            for (const [key, value] of Object.entries(profileData)) {
                if (allowedFields.includes(key) && value !== undefined) {
                    updates.push(`${key} = $${paramCount}`);
                    values.push(value);
                    paramCount++;
                }
            }
            
            if (updates.length === 0) {
                throw new Error('No valid fields to update');
            }
            
            values.push(userId); // Add user ID for WHERE clause
            
            const query = `UPDATE users SET ${updates.join(', ')} WHERE id = $${paramCount} RETURNING *`;
            const userResult = await client.query(query, values);
            
            if (userResult.rows.length === 0) {
                throw new Error('User not found');
            }
            
            const updatedUser = userResult.rows[0];
            
            // Log audit event
            await this.logAuditEvent(userId, 'profile_updated', 'users', userId, {}, profileData);
            
            return {
                success: true,
                message: 'Profile updated successfully',
                user: {
                    id: updatedUser.id,
                    email: updatedUser.email,
                    full_name: updatedUser.full_name,
                    phone_number: updatedUser.phone_number,
                    location: updatedUser.location
                }
            };
            
        } catch (error) {
            throw error;
        } finally {
            client.release();
        }
    }
    
    async logAuditEvent(userId, action, resourceType, resourceId, oldValues = {}, newValues = {}) {
        try {
            await pool.query(
                `INSERT INTO audit_logs (user_id, action, resource_type, resource_id, old_values, new_values) 
                 VALUES ($1, $2, $3, $4, $5, $6)`,
                [userId, action, resourceType, resourceId, JSON.stringify(oldValues), JSON.stringify(newValues)]
            );
        } catch (error) {
            console.error('Audit logging error:', error);
        }
    }
    
    verifyToken(token) {
        try {
            const decoded = jwt.verify(token, JWT_SECRET);
            return {
                valid: true,
                userId: decoded.userId,
                email: decoded.email,
                role: decoded.role
            };
        } catch (error) {
            return {
                valid: false,
                error: error.message
            };
        }
    }
}

module.exports = new AuthService();