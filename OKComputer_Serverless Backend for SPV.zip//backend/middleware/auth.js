const jwt = require('jsonwebtoken');
const { pool } = require('../database/connection');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

const authMiddleware = async (req, res, next) => {
    try {
        // Get token from header
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                error: 'Access denied',
                message: 'No token provided or invalid token format'
            });
        }
        
        const token = authHeader.substring(7); // Remove 'Bearer ' prefix
        
        // Verify token
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // Check if user still exists and is active
        const userResult = await pool.query(
            'SELECT id, email, full_name, role, status FROM users WHERE id = $1',
            [decoded.userId]
        );
        
        if (userResult.rows.length === 0) {
            return res.status(401).json({
                error: 'Access denied',
                message: 'User not found'
            });
        }
        
        const user = userResult.rows[0];
        
        // Check if user is active
        if (user.status !== 'approved') {
            return res.status(401).json({
                error: 'Access denied',
                message: 'Account is not active'
            });
        }
        
        // Add user to request object
        req.user = user;
        
        next();
        
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                error: 'Access denied',
                message: 'Token has expired'
            });
        }
        
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                error: 'Access denied',
                message: 'Invalid token'
            });
        }
        
        console.error('Auth middleware error:', error);
        return res.status(500).json({
            error: 'Internal server error',
            message: 'An error occurred during authentication'
        });
    }
};

// Role-based authorization middleware
const requireRole = (roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                error: 'Access denied',
                message: 'Authentication required'
            });
        }
        
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({
                error: 'Access denied',
                message: 'Insufficient permissions'
            });
        }
        
        next();
    };
};

// Admin-only middleware
const requireAdmin = requireRole(['admin']);

// Admin or reviewer middleware
const requireAdminOrReviewer = requireRole(['admin', 'reviewer']);

module.exports = {
    authMiddleware,
    requireRole,
    requireAdmin,
    requireAdminOrReviewer
};