# Backend Integration Guide

## Overview
This document provides comprehensive instructions for integrating the Livestock Fattening SPV backend with the frontend application.

## System Architecture

### Backend Components
1. **Authentication Service** (`/api/auth`) - User registration, login, password management
2. **Application Service** (`/api/applications`) - Application submission and management
3. **Investment Service** (`/api/investments`) - Investment tracking and portfolio management
4. **Admin Service** (`/api/admin`) - Administrative functions and reporting
5. **User Service** (`/api/users`) - User profile and notification management

### Database Schema
- **Users**: User accounts and authentication
- **Applications**: Investment applications and status tracking
- **Investments**: Active investments and portfolio data
- **Transactions**: Financial transactions and payouts
- **Notifications**: User notifications and alerts
- **Audit Logs**: System activity tracking

## API Integration

### Authentication Flow

#### User Registration
```javascript
const response = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        email: 'user@example.com',
        password: 'securePassword123',
        full_name: 'John Doe',
        national_id: '12345678901',
        phone_number: '+2348012345678',
        employment_status: 'employed',
        location: 'Lagos, Nigeria',
        investment_option: 'outright',
        investment_amount: 500000,
        credit_consent: false
    })
});
```

#### User Login
```javascript
const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        email: 'user@example.com',
        password: 'securePassword123'
    })
});

const result = await response.json();
if (result.success) {
    localStorage.setItem('authToken', result.token);
    localStorage.setItem('user', JSON.stringify(result.user));
}
```

#### Authenticated Requests
```javascript
const token = localStorage.getItem('authToken');
const response = await fetch('/api/applications', {
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    }
});
```

### Application Management

#### Submit Application
```javascript
const applicationData = {
    investment_option: 'outright', // 'outright' or 'financing'
    investment_amount: 500000, // for outright purchase
    monthly_repayment: 50000, // for financing option
    credit_consent: true // required for financing
};

const response = await fetch('/api/applications/submit', {
    method: 'POST',
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(applicationData)
});
```

#### Get User Applications
```javascript
const response = await fetch('/api/applications', {
    headers: { 'Authorization': `Bearer ${token}` }
});

const result = await response.json();
console.log(result.applications); // Array of applications
```

### Investment Management

#### Get User Investments
```javascript
const response = await fetch('/api/investments', {
    headers: { 'Authorization': `Bearer ${token}` }
});

const result = await response.json();
console.log(result.investments); // Array of investments
```

#### Get Dashboard Data
```javascript
const response = await fetch('/api/investments/dashboard/summary', {
    headers: { 'Authorization': `Bearer ${token}` }
});

const result = await response.json();
console.log(result.dashboard); // Dashboard statistics
```

#### Calculate Returns Projection
```javascript
const calculationData = {
    investment_amount: 500000,
    duration_months: 12,
    roi_percentage: 18
};

const response = await fetch('/api/investments/calculate-returns', {
    method: 'POST',
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(calculationData)
});
```

### User Management

#### Get User Profile
```javascript
const response = await fetch('/api/users/profile', {
    headers: { 'Authorization': `Bearer ${token}` }
});

const result = await response.json();
console.log(result.user); // User profile data
```

#### Update Profile
```javascript
const profileData = {
    full_name: 'John Updated Doe',
    phone_number: '+2348098765432',
    location: 'Abuja, Nigeria'
};

const response = await fetch('/api/users/profile', {
    method: 'PUT',
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(profileData)
});
```

#### Get Notifications
```javascript
const response = await fetch('/api/users/notifications', {
    headers: { 'Authorization': `Bearer ${token}` }
});

const result = await response.json();
console.log(result.notifications); // Array of notifications
```

### Admin Functions (Admin Users Only)

#### Get Dashboard Statistics
```javascript
const response = await fetch('/api/admin/dashboard', {
    headers: { 'Authorization': `Bearer ${token}` }
});

const result = await response.json();
console.log(result.stats); // System-wide statistics
```

#### Get All Users (Admin)
```javascript
const response = await fetch('/api/admin/users', {
    headers: { 'Authorization': `Bearer ${token}` }
});

const result = await response.json();
console.log(result.users); // Array of all users
```

#### Update Application Status (Admin)
```javascript
const statusUpdate = {
    status: 'approved', // 'approved', 'rejected', 'under_review'
    notes: 'Application approved after review'
};

const response = await fetch('/api/applications/{applicationId}/status', {
    method: 'PUT',
    headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(statusUpdate)
});
```

## Frontend Integration

### Environment Configuration
Create a `.env` file in the frontend directory:
```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_FRONTEND_URL=http://localhost:3000
```

### Authentication State Management
```javascript
class AuthManager {
    constructor() {
        this.token = localStorage.getItem('authToken');
        this.user = JSON.parse(localStorage.getItem('user') || 'null');
    }
    
    login(token, user) {
        this.token = token;
        this.user = user;
        localStorage.setItem('authToken', token);
        localStorage.setItem('user', JSON.stringify(user));
    }
    
    logout() {
        this.token = null;
        this.user = null;
        localStorage.removeItem('authToken');
        localStorage.removeItem('user');
    }
    
    isAuthenticated() {
        return !!this.token;
    }
}
```

### API Service Class
```javascript
class APIService {
    constructor(baseURL, authManager) {
        this.baseURL = baseURL;
        this.authManager = authManager;
    }
    
    async request(endpoint, options = {}) {
        const config = {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        };
        
        if (this.authManager.token) {
            config.headers['Authorization'] = `Bearer ${this.authManager.token}`;
        }
        
        const response = await fetch(`${this.baseURL}${endpoint}`, config);
        
        if (response.status === 401) {
            this.authManager.logout();
            window.location.href = '/login';
        }
        
        return response.json();
    }
    
    // Application methods
    async submitApplication(data) {
        return this.request('/applications/submit', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }
    
    async getApplications() {
        return this.request('/applications');
    }
    
    // Investment methods
    async getInvestments() {
        return this.request('/investments');
    }
    
    async getDashboard() {
        return this.request('/investments/dashboard/summary');
    }
    
    // User methods
    async getProfile() {
        return this.request('/users/profile');
    }
    
    async updateProfile(data) {
        return this.request('/users/profile', {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }
    
    async getNotifications() {
        return this.request('/users/notifications');
    }
}
```

### Error Handling
```javascript
class ErrorHandler {
    static handleAPIError(error) {
        console.error('API Error:', error);
        
        if (error.message.includes('Network')) {
            return 'Network error. Please check your connection.';
        }
        
        if (error.message.includes('401')) {
            return 'Session expired. Please login again.';
        }
        
        if (error.message.includes('403')) {
            return 'You do not have permission to perform this action.';
        }
        
        if (error.message.includes('404')) {
            return 'The requested resource was not found.';
        }
        
        return 'An error occurred. Please try again.';
    }
    
    static showError(message) {
        // Implement error display UI
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        document.body.appendChild(errorDiv);
        
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }
}
```

## Real-time Updates

### WebSocket Integration (Future Enhancement)
```javascript
class RealTimeService {
    constructor(authManager) {
        this.authManager = authManager;
        this.socket = null;
    }
    
    connect() {
        this.socket = io('ws://localhost:5000', {
            auth: {
                token: this.authManager.token
            }
        });
        
        this.socket.on('notification', (data) => {
            this.handleNotification(data);
        });
        
        this.socket.on('application_status_changed', (data) => {
            this.handleApplicationStatusChange(data);
        });
    }
    
    handleNotification(data) {
        // Display notification to user
        console.log('New notification:', data);
    }
    
    handleApplicationStatusChange(data) {
        // Update application status in UI
        console.log('Application status changed:', data);
    }
}
```

## Security Considerations

### 1. Token Storage
- Store tokens in localStorage or sessionStorage
- Implement token refresh mechanism
- Clear tokens on logout

### 2. Input Validation
- Validate all user inputs on frontend
- Sanitize data before sending to backend
- Implement proper error handling

### 3. HTTPS
- Use HTTPS in production
- Secure cookie settings
- Implement CSRF protection

### 4. Rate Limiting
- Implement frontend rate limiting
- Handle rate limit errors gracefully
- Implement retry mechanisms

## Testing

### Unit Tests
```javascript
// Example test for authentication
describe('AuthService', () => {
    test('should login successfully', async () => {
        const response = await authService.login('test@example.com', 'password');
        expect(response.success).toBe(true);
        expect(response.token).toBeDefined();
    });
    
    test('should handle login failure', async () => {
        const response = await authService.login('test@example.com', 'wrongpassword');
        expect(response.success).toBe(false);
        expect(response.error).toBeDefined();
    });
});
```

### Integration Tests
```javascript
// Example integration test
describe('Application Flow', () => {
    test('should complete full application process', async () => {
        // Register user
        const registerResponse = await authService.register(userData);
        expect(registerResponse.success).toBe(true);
        
        // Login
        const loginResponse = await authService.login(userData.email, userData.password);
        expect(loginResponse.success).toBe(true);
        
        // Submit application
        const applicationResponse = await applicationService.submit(applicationData);
        expect(applicationResponse.success).toBe(true);
        
        // Check application status
        const applicationsResponse = await applicationService.getApplications();
        expect(applicationsResponse.success).toBe(true);
        expect(applicationsResponse.applications.length).toBe(1);
    });
});
```

## Deployment

### Backend Deployment (Vercel)
```json
{
    "version": 2,
    "builds": [
        {
            "src": "backend/server.js",
            "use": "@vercel/node"
        }
    ],
    "routes": [
        {
            "src": "/api/(.*)",
            "dest": "backend/server.js"
        }
    ]
}
```

### Environment Variables
```bash
# Backend
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key
EMAIL_SERVICE=gmail
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
FRONTEND_URL=https://your-frontend-url.com

# Frontend
REACT_APP_API_URL=https://your-backend-url.com/api
```

## Monitoring and Analytics

### Error Tracking
```javascript
// Implement error tracking service
class ErrorTracker {
    static logError(error, context = {}) {
        console.error('Error logged:', error, context);
        
        // Send to error tracking service
        if (process.env.NODE_ENV === 'production') {
            // Send to Sentry, LogRocket, etc.
        }
    }
}
```

### Performance Monitoring
```javascript
// Monitor API performance
class PerformanceMonitor {
    static async measureAPI(endpoint, method) {
        const startTime = performance.now();
        
        try {
            const result = await method();
            const endTime = performance.now();
            
            console.log(`API ${endpoint} took ${endTime - startTime} milliseconds`);
            
            return result;
        } catch (error) {
            console.error(`API ${endpoint} failed:`, error);
            throw error;
        }
    }
}
```

## Troubleshooting

### Common Issues

1. **CORS Errors**
   - Ensure backend has proper CORS configuration
   - Check that frontend URL is allowed

2. **Authentication Failures**
   - Verify token is being sent correctly
   - Check token expiration
   - Ensure proper header format

3. **Database Connection Errors**
   - Verify database credentials
   - Check network connectivity
   - Ensure database is running

4. **Email Sending Failures**
   - Verify email service credentials
   - Check email service limits
   - Ensure proper email configuration

### Debug Mode
```javascript
// Enable debug mode
const DEBUG = process.env.NODE_ENV === 'development';

if (DEBUG) {
    window.DEBUG = true;
    console.log('Debug mode enabled');
}
```

## Support and Maintenance

### Regular Tasks
1. Monitor system logs
2. Update dependencies
3. Review security alerts
4. Backup database
5. Monitor performance metrics

### Documentation Updates
- Keep API documentation current
- Update integration guides
- Maintain change logs
- Document new features

## Conclusion
This integration guide provides a comprehensive framework for connecting the Livestock Fattening SPV frontend with the backend API. Follow the patterns and examples provided to ensure a robust and secure integration.

For additional support, refer to the API documentation or contact the development team.