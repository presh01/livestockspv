const express = require('express');
const router = express.Router();
const adminService = require('../admin');
const { requireAdmin } = require('../middleware/auth');

// Get dashboard statistics
router.get('/dashboard', requireAdmin, async (req, res, next) => {
    try {
        const result = await adminService.getDashboardStats();
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// User management routes
router.get('/users', requireAdmin, async (req, res, next) => {
    try {
        const { role, status, search, limit, offset } = req.query;
        
        const filters = {};
        if (role) filters.role = role;
        if (status) filters.status = status;
        if (search) filters.search = search;
        if (limit) filters.limit = parseInt(limit);
        if (offset) filters.offset = parseInt(offset);
        
        const result = await adminService.getUsers(filters);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.get('/users/:id', requireAdmin, async (req, res, next) => {
    try {
        const userId = req.params.id;
        const result = await adminService.getUser(userId);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.put('/users/:id/status', requireAdmin, async (req, res, next) => {
    try {
        const adminId = req.user.id;
        const userId = req.params.id;
        const { status, reason } = req.body;
        
        if (!status) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Status is required'
            });
        }
        
        if (!['pending', 'approved', 'rejected', 'suspended'].includes(status)) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Invalid status value'
            });
        }
        
        const result = await adminService.updateUserStatus(adminId, userId, status, reason || '');
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Application management routes
router.get('/applications', requireAdmin, async (req, res, next) => {
    try {
        const { status, investmentOption, search, startDate, endDate, limit, offset } = req.query;
        
        const filters = {};
        if (status) filters.status = status;
        if (investmentOption) filters.investmentOption = investmentOption;
        if (search) filters.search = search;
        if (startDate) filters.startDate = startDate;
        if (endDate) filters.endDate = endDate;
        if (limit) filters.limit = parseInt(limit);
        if (offset) filters.offset = parseInt(offset);
        
        const result = await adminService.getApplications(filters);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Investment management routes
router.get('/investments', requireAdmin, async (req, res, next) => {
    try {
        const { status, search, limit, offset } = req.query;
        
        const filters = {};
        if (status) filters.status = status;
        if (search) filters.search = search;
        if (limit) filters.limit = parseInt(limit);
        if (offset) filters.offset = parseInt(offset);
        
        const result = await adminService.getInvestments(filters);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Reporting routes
router.get('/reports/generate', requireAdmin, async (req, res, next) => {
    try {
        const { type, ...filters } = req.query;
        
        if (!type) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Report type is required'
            });
        }
        
        if (!['users', 'applications', 'investments', 'financial'].includes(type)) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Invalid report type'
            });
        }
        
        const result = await adminService.generateReport(type, filters);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// System settings routes
router.get('/settings', requireAdmin, async (req, res, next) => {
    try {
        const result = await pool.query('SELECT * FROM system_settings');
        
        const settings = {};
        result.rows.forEach(row => {
            settings[row.key] = {
                value: row.value,
                description: row.description
            };
        });
        
        res.json({
            success: true,
            settings: settings
        });
        
    } catch (error) {
        next(error);
    }
});

router.put('/settings/:key', requireAdmin, async (req, res, next) => {
    try {
        const { key } = req.params;
        const { value, description } = req.body;
        
        if (value === undefined) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Value is required'
            });
        }
        
        const result = await pool.query(
            `INSERT INTO system_settings (key, value, description) 
             VALUES ($1, $2, $3) 
             ON CONFLICT (key) DO UPDATE 
             SET value = $2, description = $3, updated_at = CURRENT_TIMESTAMP
             RETURNING *`,
            [key, value.toString(), description || '']
        );
        
        res.json({
            success: true,
            message: 'Setting updated successfully',
            setting: result.rows[0]
        });
        
    } catch (error) {
        next(error);
    }
});

// Audit logs routes
router.get('/audit-logs', requireAdmin, async (req, res, next) => {
    try {
        const { userId, action, resourceType, limit, offset } = req.query;
        
        let query = `
            SELECT al.*, u.full_name as user_name
            FROM audit_logs al
            LEFT JOIN users u ON al.user_id = u.id
            WHERE 1=1
        `;
        
        const params = [];
        
        if (userId) {
            params.push(userId);
            query += ` AND al.user_id = $${params.length}`;
        }
        
        if (action) {
            params.push(action);
            query += ` AND al.action = $${params.length}`;
        }
        
        if (resourceType) {
            params.push(resourceType);
            query += ` AND al.resource_type = $${params.length}`;
        }
        
        query += ' ORDER BY al.created_at DESC';
        
        if (limit) {
            params.push(parseInt(limit));
            query += ` LIMIT $${params.length}`;
        }
        
        if (offset) {
            params.push(parseInt(offset));
            query += ` OFFSET $${params.length}`;
        }
        
        const result = await pool.query(query, params);
        
        res.json({
            success: true,
            audit_logs: result.rows,
            count: result.rows.length
        });
        
    } catch (error) {
        next(error);
    }
});

// Notification management routes
router.post('/notifications/send', requireAdmin, async (req, res, next) => {
    try {
        const { userIds, title, message, type = 'in_app', data = {} } = req.body;
        
        if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'User IDs array is required'
            });
        }
        
        if (!title || !message) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Title and message are required'
            });
        }
        
        // Import notification service
        const notificationService = require('../utils/notifications');
        
        const result = await notificationService.sendBulkNotification(userIds, {
            type: type,
            category: 'admin',
            title: title,
            message: message,
            data: data
        });
        
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Cattle management routes
router.get('/cattle', requireAdmin, async (req, res, next) => {
    try {
        const { health_status, search, limit, offset } = req.query;
        
        let query = `
            SELECT c.*, i.investment_number, u.full_name as owner_name
            FROM cattle_registry c
            LEFT JOIN investments i ON c.owner_investment_id = i.id
            LEFT JOIN users u ON i.user_id = u.id
            WHERE 1=1
        `;
        
        const params = [];
        
        if (health_status) {
            params.push(health_status);
            query += ` AND c.health_status = $${params.length}`;
        }
        
        if (search) {
            params.push(`%${search}%`);
            query += ` AND (c.tag_number ILIKE $${params.length} OR c.breed ILIKE $${params.length})`;
        }
        
        query += ' ORDER BY c.created_at DESC';
        
        if (limit) {
            params.push(parseInt(limit));
            query += ` LIMIT $${params.length}`;
        }
        
        if (offset) {
            params.push(parseInt(offset));
            query += ` OFFSET $${params.length}`;
        }
        
        const result = await pool.query(query, params);
        
        res.json({
            success: true,
            cattle: result.rows,
            count: result.rows.length
        });
        
    } catch (error) {
        next(error);
    }
});

router.put('/cattle/:id/health-status', requireAdmin, async (req, res, next) => {
    try {
        const { id } = req.params;
        const { health_status } = req.body;
        
        if (!health_status) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Health status is required'
            });
        }
        
        if (!['healthy', 'sick', 'quarantined', 'deceased'].includes(health_status)) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Invalid health status'
            });
        }
        
        const result = await pool.query(
            'UPDATE cattle_registry SET health_status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *',
            [health_status, id]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'NOT_FOUND',
                message: 'Cattle not found'
            });
        }
        
        res.json({
            success: true,
            message: 'Health status updated successfully',
            cattle: result.rows[0]
        });
        
    } catch (error) {
        next(error);
    }
});

module.exports = router;