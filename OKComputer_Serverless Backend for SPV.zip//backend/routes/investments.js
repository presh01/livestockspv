const express = require('express');
const router = express.Router();
const { pool } = require('../database/connection');
const { requireAdmin } = require('../middleware/auth');

// Get user's investments
router.get('/', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { status, limit, offset } = req.query;
        
        let query = `
            SELECT i.*, a.application_number, a.investment_option
            FROM investments i
            JOIN applications a ON i.application_id = a.id
            WHERE i.user_id = $1
        `;
        
        const params = [userId];
        
        if (status) {
            params.push(status);
            query += ` AND i.status = $${params.length}`;
        }
        
        query += ' ORDER BY i.created_at DESC';
        
        if (limit) {
            params.push(parseInt(limit));
            query += ` LIMIT $${params.length}`;
        }
        
        if (offset) {
            params.push(parseInt(offset));
            query += ` OFFSET $${params.length}`;
        }
        
        const result = await pool.query(query, params);
        
        res.json({
            success: true,
            investments: result.rows,
            count: result.rows.length
        });
        
    } catch (error) {
        next(error);
    }
});

// Get specific investment
router.get('/:id', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const investmentId = req.params.id;
        
        const query = `
            SELECT i.*, a.application_number, a.investment_option
            FROM investments i
            JOIN applications a ON i.application_id = a.id
            WHERE i.id = $1 AND i.user_id = $2
        `;
        
        const result = await pool.query(query, [investmentId, userId]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'NOT_FOUND',
                message: 'Investment not found'
            });
        }
        
        // Get cattle details
        const cattleResult = await pool.query(
            'SELECT * FROM cattle_registry WHERE owner_investment_id = $1',
            [investmentId]
        );
        
        // Get recent transactions
        const transactionsResult = await pool.query(
            'SELECT * FROM transactions WHERE investment_id = $1 ORDER BY created_at DESC LIMIT 10',
            [investmentId]
        );
        
        // Get payout schedule
        const payoutsResult = await pool.query(
            'SELECT * FROM payout_schedule WHERE investment_id = $1 ORDER BY scheduled_date ASC',
            [investmentId]
        );
        
        res.json({
            success: true,
            investment: {
                ...result.rows[0],
                cattle: cattleResult.rows,
                transactions: transactionsResult.rows,
                payout_schedule: payoutsResult.rows
            }
        });
        
    } catch (error) {
        next(error);
    }
});

// Get dashboard data
router.get('/dashboard/summary', async (req, res, next) => {
    try {
        const userId = req.user.id;
        
        const dashboardQuery = `
            SELECT 
                COUNT(*) as total_investments,
                COALESCE(SUM(total_investment), 0) as total_invested,
                COALESCE(SUM(current_value), 0) as current_value,
                COALESCE(SUM(total_returns), 0) as total_returns,
                COUNT(CASE WHEN status = 'active' THEN 1 END) as active_investments,
                COUNT(CASE WHEN status = 'matured' THEN 1 END) as matured_investments
            FROM investments
            WHERE user_id = $1
        `;
        
        const result = await pool.query(dashboardQuery, [userId]);
        
        // Get recent activity
        const recentActivityQuery = `
            SELECT t.*, i.investment_number
            FROM transactions t
            JOIN investments i ON t.investment_id = i.id
            WHERE t.user_id = $1
            ORDER BY t.created_at DESC
            LIMIT 5
        `;
        
        const activityResult = await pool.query(recentActivityQuery, [userId]);
        
        // Get upcoming payouts
        const upcomingPayoutsQuery = `
            SELECT ps.*, i.investment_number
            FROM payout_schedule ps
            JOIN investments i ON ps.investment_id = i.id
            WHERE i.user_id = $1 AND ps.status = 'scheduled'
            ORDER BY ps.scheduled_date ASC
            LIMIT 5
        `;
        
        const payoutsResult = await pool.query(upcomingPayoutsQuery, [userId]);
        
        res.json({
            success: true,
            dashboard: {
                ...result.rows[0],
                recent_activity: activityResult.rows,
                upcoming_payouts: payoutsResult.rows
            }
        });
        
    } catch (error) {
        next(error);
    }
});

// Get investment performance data
router.get('/performance/chart', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { period = '12m' } = req.query;
        
        let dateFilter = '';
        switch (period) {
            case '1m':
                dateFilter = 'AND t.created_at >= CURRENT_DATE - INTERVAL \'1 month\'';
                break;
            case '3m':
                dateFilter = 'AND t.created_at >= CURRENT_DATE - INTERVAL \'3 months\'';
                break;
            case '6m':
                dateFilter = 'AND t.created_at >= CURRENT_DATE - INTERVAL \'6 months\'';
                break;
            case '1y':
                dateFilter = 'AND t.created_at >= CURRENT_DATE - INTERVAL \'1 year\'';
                break;
            default:
                dateFilter = 'AND t.created_at >= CURRENT_DATE - INTERVAL \'1 year\'';
        }
        
        const performanceQuery = `
            SELECT 
                DATE_TRUNC('month', t.created_at) as month,
                SUM(CASE WHEN t.transaction_type = 'investment' THEN t.amount ELSE 0 END) as investments,
                SUM(CASE WHEN t.transaction_type = 'return' THEN t.amount ELSE 0 END) as returns,
                COUNT(CASE WHEN t.transaction_type = 'investment' THEN 1 END) as investment_count,
                COUNT(CASE WHEN t.transaction_type = 'return' THEN 1 END) as return_count
            FROM transactions t
            JOIN investments i ON t.investment_id = i.id
            WHERE i.user_id = $1 ${dateFilter}
            GROUP BY DATE_TRUNC('month', t.created_at)
            ORDER BY month ASC
        `;
        
        const result = await pool.query(performanceQuery, [userId]);
        
        res.json({
            success: true,
            performance: result.rows
        });
        
    } catch (error) {
        next(error);
    }
});

// Calculate returns projection
router.post('/calculate-returns', async (req, res, next) => {
    try {
        const { investment_amount, duration_months, roi_percentage = 18 } = req.body;
        
        if (!investment_amount || !duration_months) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Investment amount and duration are required'
            });
        }
        
        const monthlyReturn = (investment_amount * (roi_percentage / 100)) / 12;
        const totalReturns = monthlyReturn * duration_months;
        const finalValue = investment_amount + totalReturns;
        
        const projection = [];
        for (let month = 1; month <= duration_months; month++) {
            projection.push({
                month: month,
                cumulative_return: monthlyReturn * month,
                portfolio_value: investment_amount + (monthlyReturn * month)
            });
        }
        
        res.json({
            success: true,
            calculation: {
                investment_amount: investment_amount,
                duration_months: duration_months,
                roi_percentage: roi_percentage,
                monthly_return: monthlyReturn,
                total_returns: totalReturns,
                final_value: finalValue,
                projection: projection
            }
        });
        
    } catch (error) {
        next(error);
    }
});

// Admin routes
router.get('/admin/all', requireAdmin, async (req, res, next) => {
    try {
        const { status, search, limit, offset } = req.query;
        
        let query = `
            SELECT i.*, u.full_name, u.email, a.application_number
            FROM investments i
            JOIN users u ON i.user_id = u.id
            JOIN applications a ON i.application_id = a.id
        `;
        
        const params = [];
        const conditions = [];
        
        if (status) {
            params.push(status);
            conditions.push(`i.status = $${params.length}`);
        }
        
        if (search) {
            params.push(`%${search}%`);
            conditions.push(`(u.full_name ILIKE $${params.length} OR u.email ILIKE $${params.length})`);
        }
        
        if (conditions.length > 0) {
            query += ' WHERE ' + conditions.join(' AND ');
        }
        
        query += ' ORDER BY i.created_at DESC';
        
        if (limit) {
            params.push(parseInt(limit));
            query += ` LIMIT $${params.length}`;
        }
        
        if (offset) {
            params.push(parseInt(offset));
            query += ` OFFSET $${params.length}`;
        }
        
        const result = await pool.query(query, params);
        
        res.json({
            success: true,
            investments: result.rows,
            count: result.rows.length
        });
        
    } catch (error) {
        next(error);
    }
});

router.get('/admin/summary', requireAdmin, async (req, res, next) => {
    try {
        const summaryQuery = `
            SELECT 
                COUNT(*) as total_investments,
                COALESCE(SUM(total_investment), 0) as total_invested,
                COALESCE(SUM(current_value), 0) as current_portfolio_value,
                COALESCE(SUM(total_returns), 0) as total_returns_paid,
                COUNT(CASE WHEN status = 'active' THEN 1 END) as active_investments,
                COUNT(CASE WHEN status = 'matured' THEN 1 END) as matured_investments,
                COUNT(CASE WHEN status = 'suspended' THEN 1 END) as suspended_investments
            FROM investments
        `;
        
        const result = await pool.query(summaryQuery);
        
        res.json({
            success: true,
            summary: result.rows[0]
        });
        
    } catch (error) {
        next(error);
    }
});

module.exports = router;