const express = require('express');
const router = express.Router();
const authService = require('../api/auth');
const { requireAdmin } = require('../middleware/auth');

// Public routes
router.post('/register', async (req, res, next) => {
    try {
        const { email, password, full_name, national_id, phone_number, employment_status, location, investment_option, investment_amount, monthly_repayment, credit_consent } = req.body;
        
        // Validation
        if (!email || !password || !full_name || !national_id || !investment_option) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Missing required fields'
            });
        }
        
        const userData = {
            email,
            password,
            full_name,
            national_id,
            phone_number,
            employment_status,
            location,
            investment_option,
            investment_amount: investment_amount || null,
            monthly_repayment: monthly_repayment || null,
            credit_consent: credit_consent || false
        };
        
        const result = await authService.register(userData);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.post('/login', async (req, res, next) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Email and password are required'
            });
        }
        
        const result = await authService.login(email, password);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.get('/verify/:token', async (req, res, next) => {
    try {
        const { token } = req.params;
        const result = await authService.verifyEmail(token);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.post('/forgot-password', async (req, res, next) => {
    try {
        const { email } = req.body;
        
        if (!email) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Email is required'
            });
        }
        
        const result = await authService.forgotPassword(email);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.post('/reset-password', async (req, res, next) => {
    try {
        const { token, newPassword } = req.body;
        
        if (!token || !newPassword) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Token and new password are required'
            });
        }
        
        const result = await authService.resetPassword(token, newPassword);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Protected routes
router.get('/profile', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const result = await authService.getProfile(userId);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.put('/profile', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { full_name, phone_number, location } = req.body;
        
        const profileData = {};
        if (full_name) profileData.full_name = full_name;
        if (phone_number) profileData.phone_number = phone_number;
        if (location) profileData.location = location;
        
        const result = await authService.updateProfile(userId, profileData);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.post('/change-password', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { oldPassword, newPassword } = req.body;
        
        if (!oldPassword || !newPassword) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Old password and new password are required'
            });
        }
        
        const result = await authService.changePassword(userId, oldPassword, newPassword);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

router.post('/logout', async (req, res) => {
    // For token-based auth, logout is handled client-side
    // Here we can log the logout event or perform any cleanup
    res.json({
        success: true,
        message: 'Logged out successfully'
    });
});

// Admin routes
router.get('/users', requireAdmin, async (req, res, next) => {
    try {
        const { role, status, search, limit, offset } = req.query;
        
        const filters = {};
        if (role) filters.role = role;
        if (status) filters.status = status;
        if (search) filters.search = search;
        if (limit) filters.limit = parseInt(limit);
        if (offset) filters.offset = parseInt(offset);
        
        // This would need to be implemented in auth service
        res.json({
            success: true,
            message: 'User management endpoints - to be implemented'
        });
        
    } catch (error) {
        next(error);
    }
});

module.exports = router;