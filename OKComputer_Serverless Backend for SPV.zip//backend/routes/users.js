const express = require('express');
const router = express.Router();
const { pool } = require('../database/connection');

// Get current user profile
router.get('/profile', async (req, res, next) => {
    try {
        const userId = req.user.id;
        
        const query = `
            SELECT id, email, full_name, national_id, phone_number, 
                   employment_status, location, role, status, created_at, last_login
            FROM users
            WHERE id = $1
        `;
        
        const result = await pool.query(query, [userId]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'NOT_FOUND',
                message: 'User not found'
            });
        }
        
        res.json({
            success: true,
            user: result.rows[0]
        });
        
    } catch (error) {
        next(error);
    }
});

// Update user profile
router.put('/profile', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { full_name, phone_number, location } = req.body;
        
        const allowedFields = {};
        if (full_name) allowedFields.full_name = full_name;
        if (phone_number) allowedFields.phone_number = phone_number;
        if (location) allowedFields.location = location;
        
        if (Object.keys(allowedFields).length === 0) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'No valid fields to update'
            });
        }
        
        const setClause = Object.keys(allowedFields)
            .map((key, index) => `${key} = $${index + 1}`)
            .join(', ');
        
        const params = [...Object.values(allowedFields), userId];
        
        const query = `
            UPDATE users 
            SET ${setClause}, updated_at = CURRENT_TIMESTAMP 
            WHERE id = $${params.length} 
            RETURNING id, email, full_name, phone_number, location, updated_at
        `;
        
        const result = await pool.query(query, params);
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'NOT_FOUND',
                message: 'User not found'
            });
        }
        
        res.json({
            success: true,
            message: 'Profile updated successfully',
            user: result.rows[0]
        });
        
    } catch (error) {
        next(error);
    }
});

// Get user's notifications
router.get('/notifications', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { category, type, is_read, limit, offset } = req.query;
        
        let query = `
            SELECT * FROM notifications 
            WHERE user_id = $1
        `;
        
        const params = [userId];
        
        if (category) {
            params.push(category);
            query += ` AND category = $${params.length}`;
        }
        
        if (type) {
            params.push(type);
            query += ` AND type = $${params.length}`;
        }
        
        if (is_read !== undefined) {
            if (is_read === 'true') {
                query += ` AND read_at IS NOT NULL`;
            } else {
                query += ` AND read_at IS NULL`;
            }
        }
        
        query += ' ORDER BY created_at DESC';
        
        if (limit) {
            params.push(parseInt(limit));
            query += ` LIMIT $${params.length}`;
        }
        
        if (offset) {
            params.push(parseInt(offset));
            query += ` OFFSET $${params.length}`;
        }
        
        const result = await pool.query(query, params);
        
        res.json({
            success: true,
            notifications: result.rows,
            count: result.rows.length,
            unread_count: result.rows.filter(n => !n.read_at).length
        });
        
    } catch (error) {
        next(error);
    }
});

// Mark notification as read
router.put('/notifications/:id/read', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const notificationId = req.params.id;
        
        const result = await pool.query(
            `UPDATE notifications 
             SET read_at = CURRENT_TIMESTAMP 
             WHERE id = $1 AND user_id = $2 
             RETURNING *`,
            [notificationId, userId]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'NOT_FOUND',
                message: 'Notification not found'
            });
        }
        
        res.json({
            success: true,
            notification: result.rows[0]
        });
        
    } catch (error) {
        next(error);
    }
});

// Mark all notifications as read
router.put('/notifications/read-all', async (req, res, next) => {
    try {
        const userId = req.user.id;
        
        const result = await pool.query(
            `UPDATE notifications 
             SET read_at = CURRENT_TIMESTAMP 
             WHERE user_id = $1 AND read_at IS NULL 
             RETURNING COUNT(*) as updated_count`,
            [userId]
        );
        
        res.json({
            success: true,
            updated_count: parseInt(result.rows[0].updated_count)
        });
        
    } catch (error) {
        next(error);
    }
});

// Delete notification
router.delete('/notifications/:id', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const notificationId = req.params.id;
        
        const result = await pool.query(
            'DELETE FROM notifications WHERE id = $1 AND user_id = $2 RETURNING *',
            [notificationId, userId]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'NOT_FOUND',
                message: 'Notification not found'
            });
        }
        
        res.json({
            success: true,
            message: 'Notification deleted successfully'
        });
        
    } catch (error) {
        next(error);
    }
});

// Get user's dashboard summary
router.get('/dashboard', async (req, res, next) => {
    try {
        const userId = req.user.id;
        
        // Get user summary
        const userSummaryQuery = `
            SELECT 
                u.*,
                COUNT(i.id) as total_investments,
                COALESCE(SUM(i.total_investment), 0) as total_invested,
                COALESCE(SUM(i.current_value), 0) as current_value,
                COALESCE(SUM(i.total_returns), 0) as total_returns,
                MAX(i.created_at) as last_investment_date
            FROM users u
            LEFT JOIN investments i ON u.id = i.user_id AND i.status = 'active'
            WHERE u.id = $1
            GROUP BY u.id
        `;
        
        const userResult = await pool.query(userSummaryQuery, [userId]);
        
        if (userResult.rows.length === 0) {
            return res.status(404).json({
                error: 'NOT_FOUND',
                message: 'User not found'
            });
        }
        
        const user = userResult.rows[0];
        
        // Get recent activity
        const recentActivityQuery = `
            SELECT t.*, i.investment_number
            FROM transactions t
            JOIN investments i ON t.investment_id = i.id
            WHERE t.user_id = $1
            ORDER BY t.created_at DESC
            LIMIT 10
        `;
        
        const activityResult = await pool.query(recentActivityQuery, [userId]);
        
        // Get application status
        const applicationStatusQuery = `
            SELECT 
                COUNT(*) as total_applications,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_applications,
                COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_applications,
                COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected_applications
            FROM applications
            WHERE user_id = $1
        `;
        
        const applicationResult = await pool.query(applicationStatusQuery, [userId]);
        
        // Get upcoming payouts
        const upcomingPayoutsQuery = `
            SELECT ps.*, i.investment_number
            FROM payout_schedule ps
            JOIN investments i ON ps.investment_id = i.id
            WHERE i.user_id = $1 AND ps.status = 'scheduled'
            ORDER BY ps.scheduled_date ASC
            LIMIT 5
        `;
        
        const payoutsResult = await pool.query(upcomingPayoutsQuery, [userId]);
        
        res.json({
            success: true,
            dashboard: {
                user: user,
                applications: applicationResult.rows[0],
                recent_activity: activityResult.rows,
                upcoming_payouts: payoutsResult.rows
            }
        });
        
    } catch (error) {
        next(error);
    }
});

module.exports = router;