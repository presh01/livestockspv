const express = require('express');
const router = express.Router();
const applicationService = require('../api/applications');
const { requireAdminOrReviewer } = require('../middleware/auth');

// Submit new application
router.post('/submit', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const applicationData = req.body;
        
        // Validation
        if (!applicationData.investment_option) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Investment option is required'
            });
        }
        
        if (applicationData.investment_option === 'outright' && !applicationData.investment_amount) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Investment amount is required for outright purchase'
            });
        }
        
        if (applicationData.investment_option === 'financing' && !applicationData.monthly_repayment) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Monthly repayment amount is required for financing option'
            });
        }
        
        if (applicationData.investment_option === 'financing' && !applicationData.credit_consent) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Credit search consent is required for financing option'
            });
        }
        
        const result = await applicationService.submitApplication(userId, applicationData);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Get user's applications
router.get('/', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const role = req.user.role;
        const { status, startDate, endDate, limit, offset } = req.query;
        
        const filters = {};
        if (status) filters.status = status;
        if (startDate) filters.startDate = startDate;
        if (endDate) filters.endDate = endDate;
        if (limit) filters.limit = parseInt(limit);
        if (offset) filters.offset = parseInt(offset);
        
        const result = await applicationService.getApplications(userId, role, filters);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Get specific application
router.get('/:id', async (req, res, next) => {
    try {
        const userId = req.user.id;
        const role = req.user.role;
        const applicationId = req.params.id;
        
        const result = await applicationService.getApplication(userId, applicationId, role);
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Admin/Reviewer routes
router.put('/:id/status', requireAdminOrReviewer, async (req, res, next) => {
    try {
        const adminId = req.user.id;
        const applicationId = req.params.id;
        const { status, notes } = req.body;
        
        if (!status) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Status is required'
            });
        }
        
        if (!['approved', 'rejected', 'under_review'].includes(status)) {
            return res.status(400).json({
                error: 'VALIDATION_ERROR',
                message: 'Invalid status value'
            });
        }
        
        const result = await applicationService.updateApplicationStatus(adminId, applicationId, status, notes || '');
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Get application statistics (admin only)
router.get('/stats/overview', requireAdminOrReviewer, async (req, res, next) => {
    try {
        const result = await applicationService.getApplicationStats();
        res.json(result);
        
    } catch (error) {
        next(error);
    }
});

// Upload application documents
router.post('/:id/documents', async (req, res, next) => {
    try {
        // This would handle file uploads
        // Implementation depends on the file upload middleware being used
        res.json({
            success: true,
            message: 'Document upload endpoint - to be implemented with file upload middleware'
        });
        
    } catch (error) {
        next(error);
    }
});

// Get application documents
router.get('/:id/documents', async (req, res, next) => {
    try {
        const applicationId = req.params.id;
        
        // This would retrieve uploaded documents
        res.json({
            success: true,
            message: 'Document retrieval endpoint - to be implemented'
        });
        
    } catch (error) {
        next(error);
    }
});

module.exports = router;