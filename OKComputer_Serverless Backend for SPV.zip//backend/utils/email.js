const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

class EmailService {
    constructor() {
        this.transporter = null;
        this.templates = {};
        this.initializeTransporter();
        this.loadTemplates();
    }
    
    initializeTransporter() {
        // Configure email transporter
        if (process.env.EMAIL_SERVICE === 'gmail') {
            this.transporter = nodemailer.createTransporter({
                service: 'gmail',
                auth: {
                    user: process.env.EMAIL_USER,
                    pass: process.env.EMAIL_PASSWORD
                }
            });
        } else if (process.env.RESEND_API_KEY) {
            // Resend API for production
            this.transporter = {
                sendMail: async (options) => {
                    const resend = require('resend');
                    const client = new resend.Resend(process.env.RESEND_API_KEY);
                    
                    return await client.emails.send({
                        from: process.env.EMAIL_FROM || 'LivestockSPV <noreply@livestockspv.com>',
                        to: options.to,
                        subject: options.subject,
                        html: options.html
                    });
                }
            };
        } else {
            // Default SMTP configuration
            this.transporter = nodemailer.createTransporter({
                host: process.env.SMTP_HOST || 'smtp.gmail.com',
                port: parseInt(process.env.SMTP_PORT) || 587,
                secure: process.env.SMTP_SECURE === 'true',
                auth: {
                    user: process.env.SMTP_USER,
                    pass: process.env.SMTP_PASSWORD
                }
            });
        }
    }
    
    loadTemplates() {
        const templatesDir = path.join(__dirname, 'templates');
        
        // Create templates directory if it doesn't exist
        if (!fs.existsSync(templatesDir)) {
            fs.mkdirSync(templatesDir, { recursive: true });
            this.createDefaultTemplates();
        }
        
        // Load template files
        const templateFiles = fs.readdirSync(templatesDir);
        templateFiles.forEach(file => {
            if (file.endsWith('.html')) {
                const templateName = file.replace('.html', '');
                this.templates[templateName] = fs.readFileSync(
                    path.join(templatesDir, file), 
                    'utf8'
                );
            }
        });
    }
    
    createDefaultTemplates() {
        const templatesDir = path.join(__dirname, 'templates');
        
        // Email Verification Template
        const emailVerificationTemplate = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Email Verification - LivestockSPV</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #2D5016; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .button { display: inline-block; padding: 12px 24px; background: #D4AF37; color: white; text-decoration: none; border-radius: 5px; }
        .footer { background: #eee; padding: 20px; text-align: center; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Welcome to LivestockSPV</h1>
        </div>
        <div class="content">
            <h2>Hello {{full_name}},</h2>
            <p>Thank you for registering with LivestockSPV. Your application number is: <strong>{{application_number}}</strong></p>
            <p>Please verify your email address by clicking the button below:</p>
            <p style="text-align: center;">
                <a href="{{verification_url}}" class="button">Verify Email Address</a>
            </p>
            <p>If you didn't create this account, please ignore this email.</p>
        </div>
        <div class="footer">
            <p>This is an automated email. Please do not reply.</p>
            <p>© 2025 LivestockSPV. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;
        
        // Application Received Template
        const applicationReceivedTemplate = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Application Received - LivestockSPV</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #2D5016; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .status-box { background: #e8f5e8; border: 1px solid #4caf50; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .footer { background: #eee; padding: 20px; text-align: center; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Application Received</h1>
        </div>
        <div class="content">
            <h2>Hello {{full_name}},</h2>
            <p>We have successfully received your application for the Livestock Fattening SPV.</p>
            
            <div class="status-box">
                <h3>Application Details</h3>
                <p><strong>Application Number:</strong> {{application_number}}</p>
                <p><strong>Investment Option:</strong> {{investment_option}}</p>
                <p><strong>Status:</strong> Pending Review</p>
            </div>
            
            <p>Our team will review your application within 24 hours. You will receive an email notification once the review is complete.</p>
            
            <p>Thank you for choosing LivestockSPV!</p>
        </div>
        <div class="footer">
            <p>This is an automated email. Please do not reply.</p>
            <p>© 2025 LivestockSPV. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;
        
        // Application Approved Template
        const applicationApprovedTemplate = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Application Approved - LivestockSPV</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #4caf50; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .success-box { background: #e8f5e8; border: 1px solid #4caf50; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .button { display: inline-block; padding: 12px 24px; background: #2D5016; color: white; text-decoration: none; border-radius: 5px; }
        .footer { background: #eee; padding: 20px; text-align: center; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Application Approved! 🎉</h1>
        </div>
        <div class="content">
            <h2>Congratulations {{full_name}}!</h2>
            <p>Your application <strong>{{application_number}}</strong> has been approved.</p>
            
            <div class="success-box">
                <h3>Next Steps</h3>
                <p>Your investment account has been created and you can now access your dashboard.</p>
                <p><strong>Approval Notes:</strong> {{approval_notes}}</p>
            </div>
            
            <p style="text-align: center;">
                <a href="{{dashboard_url}}" class="button">Access Dashboard</a>
            </p>
            
            <p>Thank you for investing with LivestockSPV!</p>
        </div>
        <div class="footer">
            <p>This is an automated email. Please do not reply.</p>
            <p>© 2025 LivestockSPV. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;
        
        // Password Reset Template
        const passwordResetTemplate = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Password Reset - LivestockSPV</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #2D5016; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; background: #f9f9f9; }
        .button { display: inline-block; padding: 12px 24px; background: #D4AF37; color: white; text-decoration: none; border-radius: 5px; }
        .footer { background: #eee; padding: 20px; text-align: center; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Password Reset</h1>
        </div>
        <div class="content">
            <h2>Hello {{full_name}},</h2>
            <p>We received a request to reset your password. Click the button below to reset it:</p>
            <p style="text-align: center;">
                <a href="{{reset_url}}" class="button">Reset Password</a>
            </p>
            <p>This link will expire in 1 hour for security reasons.</p>
            <p>If you didn't request this reset, please ignore this email.</p>
        </div>
        <div class="footer">
            <p>This is an automated email. Please do not reply.</p>
            <p>© 2025 LivestockSPV. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;
        
        // Write templates to files
        fs.writeFileSync(path.join(templatesDir, 'email-verification.html'), emailVerificationTemplate);
        fs.writeFileSync(path.join(templatesDir, 'application-received.html'), applicationReceivedTemplate);
        fs.writeFileSync(path.join(templatesDir, 'application-approved.html'), applicationApprovedTemplate);
        fs.writeFileSync(path.join(templatesDir, 'password-reset.html'), passwordResetTemplate);
    }
    
    async sendEmail({ to, subject, template, data = {}, attachments = [] }) {
        try {
            // Get template
            let html = this.templates[template];
            if (!html) {
                throw new Error(`Email template '${template}' not found`);
            }
            
            // Replace template variables
            for (const [key, value] of Object.entries(data)) {
                const regex = new RegExp(`{{${key}}}`, 'g');
                html = html.replace(regex, value);
            }
            
            // Add default URLs if not provided
            if (!data.verification_url) {
                html = html.replace(/{{verification_url}}/g, `${process.env.FRONTEND_URL}/verify-email?token=${data.verification_token}`);
            }
            
            if (!data.reset_url) {
                html = html.replace(/{{reset_url}}/g, `${process.env.FRONTEND_URL}/reset-password?token=${data.reset_token}`);
            }
            
            if (!data.dashboard_url) {
                html = html.replace(/{{dashboard_url}}/g, `${process.env.FRONTEND_URL}/dashboard`);
            }
            
            // Email options
            const mailOptions = {
                from: process.env.EMAIL_FROM || 'LivestockSPV <noreply@livestockspv.com>',
                to: Array.isArray(to) ? to.join(', ') : to,
                subject: subject,
                html: html,
                attachments: attachments
            };
            
            // Send email
            const result = await this.transporter.sendMail(mailOptions);
            
            console.log(`Email sent successfully to ${to}`);
            return {
                success: true,
                messageId: result.messageId,
                result: result
            };
            
        } catch (error) {
            console.error('Email sending error:', error);
            throw new Error(`Failed to send email: ${error.message}`);
        }
    }
    
    async sendBulkEmail(recipients, subject, template, data = {}) {
        const results = [];
        
        for (const recipient of recipients) {
            try {
                const personalizedData = { ...data, ...recipient.data };
                const result = await this.sendEmail({
                    to: recipient.email,
                    subject: subject,
                    template: template,
                    data: personalizedData
                });
                results.push({ email: recipient.email, success: true, result });
            } catch (error) {
                results.push({ email: recipient.email, success: false, error: error.message });
            }
        }
        
        return {
            success: true,
            total: recipients.length,
            successful: results.filter(r => r.success).length,
            failed: results.filter(r => !r.success).length,
            results: results
        };
    }
    
    async sendSMS(to, message) {
        // SMS implementation using Twilio or similar service
        try {
            if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
                const twilio = require('twilio');
                const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
                
                const result = await client.messages.create({
                    body: message,
                    from: process.env.TWILIO_PHONE_NUMBER,
                    to: to
                });
                
                return {
                    success: true,
                    messageSid: result.sid
                };
            } else {
                console.log(`SMS to ${to}: ${message}`);
                return {
                    success: true,
                    message: 'SMS service not configured - logged to console'
                };
            }
        } catch (error) {
            console.error('SMS sending error:', error);
            throw new Error(`Failed to send SMS: ${error.message}`);
        }
    }
}

module.exports = new EmailService();