const { pool } = require('../database/connection');
const { sendEmail, sendSMS } = require('./email');

class NotificationService {
    async createNotification({ userId, type, category, title, message, data = {} }) {
        try {
            // Create in-app notification
            const result = await pool.query(
                `INSERT INTO notifications (user_id, type, category, title, message, data) 
                 VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
                [userId, type, category, title, message, JSON.stringify(data)]
            );
            
            const notification = result.rows[0];
            
            // Send real-time notification if user is online
            await this.sendRealTimeNotification(userId, notification);
            
            return {
                success: true,
                notification: notification
            };
            
        } catch (error) {
            console.error('Error creating notification:', error);
            throw error;
        }
    }
    
    async sendRealTimeNotification(userId, notification) {
        // Implementation for real-time notifications using WebSocket or similar
        // This would integrate with your real-time messaging system
        try {
            // Emit notification to user's room/channel
            if (global.io) {
                global.io.to(`user_${userId}`).emit('notification', {
                    id: notification.id,
                    title: notification.title,
                    message: notification.message,
                    data: notification.data,
                    created_at: notification.created_at
                });
            }
        } catch (error) {
            console.error('Error sending real-time notification:', error);
        }
    }
    
    async sendNotification({ userId, type, category, title, message, data = {}, channels = ['in_app'] }) {
        try {
            const results = {};
            
            // Always create in-app notification
            const inAppResult = await this.createNotification({
                userId, type, category, title, message, data
            });
            results.in_app = inAppResult;
            
            // Get user details
            const userResult = await pool.query(
                'SELECT email, phone_number FROM users WHERE id = $1',
                [userId]
            );
            
            if (userResult.rows.length === 0) {
                throw new Error('User not found');
            }
            
            const user = userResult.rows[0];
            
            // Send email notification
            if (channels.includes('email') && user.email) {
                try {
                    const emailResult = await sendEmail({
                        to: user.email,
                        subject: title,
                        template: 'notification',
                        data: {
                            title: title,
                            message: message,
                            ...data
                        }
                    });
                    results.email = emailResult;
                } catch (emailError) {
                    console.error('Email notification error:', emailError);
                    results.email = { success: false, error: emailError.message };
                }
            }
            
            // Send SMS notification
            if (channels.includes('sms') && user.phone_number) {
                try {
                    const smsResult = await sendSMS(user.phone_number, message);
                    results.sms = smsResult;
                } catch (smsError) {
                    console.error('SMS notification error:', smsError);
                    results.sms = { success: false, error: smsError.message };
                }
            }
            
            return {
                success: true,
                results: results
            };
            
        } catch (error) {
            console.error('Error sending notification:', error);
            throw error;
        }
    }
    
    async getNotifications(userId, filters = {}) {
        try {
            let query = `
                SELECT * FROM notifications 
                WHERE user_id = $1
            `;
            
            const params = [userId];
            
            if (filters.category) {
                params.push(filters.category);
                query += ` AND category = $${params.length}`;
            }
            
            if (filters.type) {
                params.push(filters.type);
                query += ` AND type = $${params.length}`;
            }
            
            if (filters.is_read !== undefined) {
                if (filters.is_read) {
                    query += ` AND read_at IS NOT NULL`;
                } else {
                    query += ` AND read_at IS NULL`;
                }
            }
            
            query += ' ORDER BY created_at DESC';
            
            if (filters.limit) {
                params.push(filters.limit);
                query += ` LIMIT $${params.length}`;
            }
            
            if (filters.offset) {
                params.push(filters.offset);
                query += ` OFFSET $${params.length}`;
            }
            
            const result = await pool.query(query, params);
            
            return {
                success: true,
                notifications: result.rows,
                count: result.rows.length,
                unread_count: result.rows.filter(n => !n.read_at).length
            };
            
        } catch (error) {
            console.error('Error getting notifications:', error);
            throw error;
        }
    }
    
    async markAsRead(userId, notificationId) {
        try {
            const result = await pool.query(
                `UPDATE notifications 
                 SET read_at = CURRENT_TIMESTAMP 
                 WHERE id = $1 AND user_id = $2 
                 RETURNING *`,
                [notificationId, userId]
            );
            
            if (result.rows.length === 0) {
                throw new Error('Notification not found');
            }
            
            return {
                success: true,
                notification: result.rows[0]
            };
            
        } catch (error) {
            console.error('Error marking notification as read:', error);
            throw error;
        }
    }
    
    async markAllAsRead(userId) {
        try {
            const result = await pool.query(
                `UPDATE notifications 
                 SET read_at = CURRENT_TIMESTAMP 
                 WHERE user_id = $1 AND read_at IS NULL 
                 RETURNING COUNT(*) as updated_count`,
                [userId]
            );
            
            return {
                success: true,
                updated_count: parseInt(result.rows[0].updated_count)
            };
            
        } catch (error) {
            console.error('Error marking all notifications as read:', error);
            throw error;
        }
    }
    
    async deleteNotification(userId, notificationId) {
        try {
            const result = await pool.query(
                'DELETE FROM notifications WHERE id = $1 AND user_id = $2 RETURNING *',
                [notificationId, userId]
            );
            
            if (result.rows.length === 0) {
                throw new Error('Notification not found');
            }
            
            return {
                success: true,
                message: 'Notification deleted successfully'
            };
            
        } catch (error) {
            console.error('Error deleting notification:', error);
            throw error;
        }
    }
    
    async getUnreadCount(userId) {
        try {
            const result = await pool.query(
                'SELECT COUNT(*) as unread_count FROM notifications WHERE user_id = $1 AND read_at IS NULL',
                [userId]
            );
            
            return {
                success: true,
                unread_count: parseInt(result.rows[0].unread_count)
            };
            
        } catch (error) {
            console.error('Error getting unread count:', error);
            throw error;
        }
    }
    
    async sendBulkNotification(userIds, notificationData) {
        const results = [];
        
        for (const userId of userIds) {
            try {
                const result = await this.sendNotification({
                    userId: userId,
                    ...notificationData
                });
                results.push({ userId, success: true, result });
            } catch (error) {
                results.push({ userId, success: false, error: error.message });
            }
        }
        
        return {
            success: true,
            total: userIds.length,
            successful: results.filter(r => r.success).length,
            failed: results.filter(r => !r.success).length,
            results: results
        };
    }
    
    // Notification templates for common events
    async notifyApplicationSubmitted(userId, applicationNumber) {
        return await this.sendNotification({
            userId: userId,
            type: 'in_app',
            category: 'application',
            title: 'Application Submitted',
            message: `Your application ${applicationNumber} has been submitted successfully.`,
            data: { application_number: applicationNumber }
        });
    }
    
    async notifyApplicationApproved(userId, applicationNumber) {
        return await this.sendNotification({
            userId: userId,
            type: 'in_app',
            category: 'application',
            title: 'Application Approved',
            message: `Your application ${applicationNumber} has been approved!`,
            data: { application_number: applicationNumber },
            channels: ['in_app', 'email']
        });
    }
    
    async notifyApplicationRejected(userId, applicationNumber, reason) {
        return await this.sendNotification({
            userId: userId,
            type: 'in_app',
            category: 'application',
            title: 'Application Update',
            message: `Your application ${applicationNumber} was not approved.`,
            data: { 
                application_number: applicationNumber,
                reason: reason
            },
            channels: ['in_app', 'email']
        });
    }
    
    async notifyPayoutScheduled(userId, investmentId, amount, date) {
        return await this.sendNotification({
            userId: userId,
            type: 'in_app',
            category: 'investment',
            title: 'Payout Scheduled',
            message: `A payout of ${amount} has been scheduled for ${date}.`,
            data: { 
                investment_id: investmentId,
                amount: amount,
                date: date
            },
            channels: ['in_app', 'email']
        });
    }
    
    async notifyPayoutCompleted(userId, investmentId, amount) {
        return await this.sendNotification({
            userId: userId,
            type: 'in_app',
            category: 'investment',
            title: 'Payout Completed',
            message: `Your payout of ${amount} has been completed.`,
            data: { 
                investment_id: investmentId,
                amount: amount
            },
            channels: ['in_app', 'email', 'sms']
        });
    }
    
    async notifyInvestmentMatured(userId, investmentId, totalReturns) {
        return await this.sendNotification({
            userId: userId,
            type: 'in_app',
            category: 'investment',
            title: 'Investment Matured',
            message: `Your investment has matured with total returns of ${totalReturns}.`,
            data: { 
                investment_id: investmentId,
                total_returns: totalReturns
            },
            channels: ['in_app', 'email', 'sms']
        });
    }
    
    async notifyAdminEvent(adminUserIds, title, message, data = {}) {
        return await this.sendBulkNotification(adminUserIds, {
            type: 'in_app',
            category: 'admin',
            title: title,
            message: message,
            data: data,
            channels: ['in_app', 'email']
        });
    }
}

module.exports = new NotificationService();