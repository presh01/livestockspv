# Livestock Fattening SPV - Backend System

## System Architecture

### Technology Stack
- **Backend Framework**: Node.js with Express.js
- **Database**: SQLite (development) / PostgreSQL (production)
- **Authentication**: JWT (JSON Web Tokens)
- **File Storage**: Local storage (development) / AWS S3 (production)
- **Email Service**: Nodemailer with SMTP
- **Admin Panel**: React-based Dashboard
- **API Documentation**: Swagger/OpenAPI

### Serverless Architecture Components
- **API Routes**: Next.js API routes for serverless deployment
- **Database**: Supabase (PostgreSQL) for serverless database
- **Authentication**: NextAuth.js for serverless auth
- **File Storage**: Vercel Blob storage
- **Email**: Resend API for serverless email

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    national_id VARCHAR(20) UNIQUE NOT NULL,
    phone_number VARCHAR(20),
    employment_status VARCHAR(50),
    location VARCHAR(255),
    email_verified BOOLEAN DEFAULT FALSE,
    role VARCHAR(20) DEFAULT 'investor',
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Applications Table
```sql
CREATE TABLE applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    application_number VARCHAR(50) UNIQUE NOT NULL,
    investment_option VARCHAR(20) NOT NULL,
    investment_amount DECIMAL(15,2),
    monthly_repayment DECIMAL(10,2),
    credit_consent BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'pending',
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMP,
    approval_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Investments Table
```sql
CREATE TABLE investments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    application_id UUID REFERENCES applications(id) ON DELETE CASCADE,
    cattle_count INTEGER DEFAULT 0,
    total_investment DECIMAL(15,2) DEFAULT 0,
    current_value DECIMAL(15,2) DEFAULT 0,
    total_returns DECIMAL(15,2) DEFAULT 0,
    last_payout_date DATE,
    next_payout_date DATE,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Transactions Table
```sql
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    investment_id UUID REFERENCES investments(id) ON DELETE CASCADE,
    transaction_type VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    description TEXT,
    reference_number VARCHAR(100),
    status VARCHAR(20) DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/verify` - Email verification
- `POST /api/auth/reset-password` - Password reset

### Applications
- `POST /api/applications/submit` - Submit new application
- `GET /api/applications` - Get user's applications
- `GET /api/applications/:id` - Get specific application
- `PUT /api/applications/:id/status` - Update application status (admin)
- `GET /api/applications/all` - Get all applications (admin)

### Investments
- `GET /api/investments` - Get user's investments
- `GET /api/investments/dashboard` - Get dashboard data
- `POST /api/investments/calculate` - Calculate returns
- `GET /api/investments/performance` - Get performance metrics

### Admin
- `GET /api/admin/stats` - Get system statistics
- `GET /api/admin/users` - Get all users
- `PUT /api/admin/users/:id/status` - Update user status
- `GET /api/admin/reports` - Generate reports
- `POST /api/admin/notify` - Send notifications

## Features Implementation

### 1. Application Management
- Multi-step application form with validation
- Document upload functionality
- Automated application number generation
- Status tracking with email notifications

### 2. User Management
- Role-based access control (investor, admin, reviewer)
- Profile management
- Password reset functionality
- Email verification system

### 3. Investment Tracking
- Real-time portfolio value calculation
- Automated returns computation
- Payout scheduling and tracking
- Performance analytics and charts

### 4. Admin Dashboard
- Application review and approval workflow
- User management interface
- System analytics and reporting
- Bulk operations and communications

### 5. Notification System
- Email notifications for status changes
- SMS alerts for important updates
- In-app notifications
- Automated reminder system

### 6. Security Features
- JWT-based authentication
- Input validation and sanitization
- Rate limiting and throttling
- Audit logging for all actions

## Deployment Strategy

### Development Environment
- Local SQLite database
- File-based storage
- SMTP email configuration
- Hot reloading for development

### Production Environment
- Vercel serverless deployment
- Supabase PostgreSQL database
- Vercel Blob storage
- Resend email API
- Custom domain configuration

## Monitoring and Analytics
- Application performance monitoring
- User behavior tracking
- Error logging and reporting
- Business metrics dashboard

## Backup and Recovery
- Automated database backups
- File storage redundancy
- Disaster recovery procedures
- Data retention policies